
package geometrydash;

import java.awt.Color;
import java.util.ArrayList;

public class Livello {
    private int lMSpino = 50, AMSpino = 50;
    private ArrayList<Img> spiniLivello = new ArrayList<>();
    private ArrayList<Img> piattaformeLivello = new ArrayList<>();
    private ArrayList<Img> portaliGravitaGialloLivello = new ArrayList<>();
    private ArrayList<Img> portaliGravitaBluLivello = new ArrayList<>();
    private ArrayList<Img> portaliNavicellaLivello = new ArrayList<>();
    private ArrayList<Img> portaliCuboLivello = new ArrayList<>();
    private ArrayList<Img> fine = new ArrayList<>();
    private Color LvColor;
    public Livello(int numero) {
        switch(numero) {
            case 1: creaLivelloUno(); break;
            case 2: creaLivelloDue(); break; 
            case 3: creaLivelloTre(); break;
        }
    }
    
public void creaLivelloUno() {
    LvColor = Color.blue;

    int groundY = 900;
    int step = 660;
    int offset = 1900;

    // ================================================================
    // SEZIONE 1 — INTRODUZIONE (step 2-7)
    // ================================================================

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 2 + offset, groundY));

    // Piattaforma bassa — spino SOTTO a destra: devi salirci sopra
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 3 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 3 + 60 + offset, groundY)); // sotto la piattaforma

    // Doppio spino a terra
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 4 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 4 + 45 + offset, groundY));

    // Piattaforma con spino SOTTO — il giocatore deve salire
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 5 + offset, groundY - 150));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 5 + 60 + offset, groundY)); // sotto

    // ================================================================
    // SEZIONE 2 — SCALA ASCENDENTE (step 7-11)
    // ================================================================

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7 + offset, groundY - 120));
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7 + 250 + offset, groundY - 240));
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7 + 500 + offset, groundY - 360));

    // Spino SOTTO la piattaforma più alta — chi non sale muore
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 7 + 520 + offset, groundY));

    // Doppio spino dopo la discesa
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 8 + 200 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 8 + 245 + offset, groundY));

    // Piattaforma singola con spino SOTTO
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 9 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 9 + 70 + offset, groundY)); // sotto

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 10 + offset, groundY));

    // ================================================================
    // SEZIONE 3 — PIATTAFORME ALTERNATE (step 11-16)
    // ================================================================

    for (int i = 0; i < 5; i++) {
        int xP = step * 11 + i * 350 + offset;
        int altezza = (i % 2 == 0) ? groundY - 130 : groundY - 270;
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 170, 40, xP, altezza));

        // Spino SOTTO tutte le piattaforme — l'aria sotto non è mai sicura
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xP + 70, groundY));
    }

    // Doppio spino a terra tra le sezioni
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 13 + 100 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 13 + 145 + offset, groundY));

    // ================================================================
    // SEZIONE 4 — COSTRUZIONE RITMICA (step 17-22)
    // ================================================================

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 17 + offset, groundY));

    // Piattaforma con due spini SOTTO affiancati
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 200, 40, step * 18 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 18 + 30 + offset, groundY));  // sotto
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 18 + 75 + offset, groundY)); // sotto

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 19 + offset, groundY));

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 140, 40, step * 20 + offset, groundY - 100));
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 140, 40, step * 20 + 300 + offset, groundY - 200));
    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 140, 40, step * 20 + 600 + offset, groundY - 300));

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 20 + 60 + offset, groundY));  // sotto gradino 1
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 20 + 280 + offset, groundY)); // sotto gradino 2

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 21 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 21 + 45 + offset, groundY));

    // ================================================================
    // SEZIONE 5 — CORRIDOIO DI PIATTAFORME (step 22-27)
    // ================================================================

    for (int i = 0; i < 4; i++) {
        int xP = step * 22 + i * 400 + offset;
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 200, 40, xP, groundY - 330));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xP + 100, groundY)); // sotto
    }

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 24 + 40 + offset, groundY));


    // ================================================================
    // SEZIONE 6 — BUILD-UP PRE-TRIPLO (step 27-29)
    // ================================================================

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 140, 40, step * 27 + offset, groundY - 140));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 27 + 60 + offset, groundY)); // sotto

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 140, 40, step * 27 + 250 + offset, groundY - 260));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 27 + 310 + offset, groundY)); // sotto

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 28 + offset - 50, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 28 - 5 + offset, groundY));

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 200, 40, step * 29 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 29 + 220 + offset, groundY));

    // ================================================================
    // SEZIONE 7 — IL TRIPLO SPINO (step 30)
    // ================================================================

    int tripleX = step * 30;
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, tripleX + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, tripleX + 45 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, tripleX + 90 + offset, groundY));

    // ================================================================
    // SEZIONE 8 — RESPIRO POST-TRIPLO (step 31-36)
    // ================================================================

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 32 + offset, groundY));

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 33 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 33 + 60 + offset, groundY)); // sotto

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 34 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 34 + 45 + offset, groundY));

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 170, 40, step * 35 + offset, groundY -120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 35 + 80 + offset, groundY)); // sotto

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 36 + offset, groundY));

    // ================================================================
    // SEZIONE 9 — SEQUENZA MISTA FINALE DA CUBO (step 37-44)
    // ================================================================

    for (int i = 0; i < 5; i++) {
        int xP = step * 37 + i * 350 + offset;
        int altezza = (i % 2 == 0) ? groundY - 140 : groundY - 280;
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 160, 40, xP, altezza));
        // Spino SOTTO ogni piattaforma — vietato restare a terra
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xP + 70, groundY));
    }

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 39 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 39 + 45 + offset, groundY));


    // ================================================================
    // SEZIONE 10 — PORTALE NAVICELLA (step 45)
    // ================================================================

    portaliNavicellaLivello.add(new Img("/resources/images/ship_portal.png", "portaleNavicella", 100, 200, step * 45, groundY - 200));
    
    for (int i = 0; i < 50; i++) {
        int xNav = step * 46 + i * 45 + offset;
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xNav, groundY));
    }
    
    for (int i = 0; i < 50; i++) {
        int xNav = step * 46 + i * 45 + offset;
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xNav, groundY - 900));
        spiniLivello.getLast().setRotation(180);
    }
    
    for (int i = 0; i < 10; i++) {
        int yNav = 0 + (i*67);
        spiniLivello.add(new Img("/resources/images/piattaforma.png", "piattaforma", 67, 67, step * 53, yNav));
        
    }

    // Spini a mezz'aria alternati alto/basso — slalom aereo
    for (int i = 0; i < 8; i++) {
        int xNav = step * 46 + i * 280 + offset;
        int yNav = (i % 2 == 0) ? groundY - 280 : groundY - 520;
        spiniLivello.add(new Img("/resources/images/piattaforma.png", "piattaforma", 67, 67, xNav, yNav));
    }

    // ================================================================
    // SEZIONE 11 — RITORNO AL CUBO + FINALE (step 53-58)
    // ================================================================

    portaliCuboLivello.add(new Img("/resources/images/cube_portal.png", "portaleCubo", 100, 200, step * 53, groundY - 200));

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 54 + offset, groundY));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 54 + 45 + offset, groundY));

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 55 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 55 + 60 + offset, groundY)); // sotto

    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 56 + offset, groundY));

    piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 57 + offset, groundY - 120));
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 57 + 70 + offset, groundY)); // sotto

    // L'ultimo spino. Il punto finale. La fine del discorso.
    spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 58 + offset, groundY));
    
    fine.add(new Img("/resources/images/anonimo.png", "spina", 100, 1000, step * 59 + offset, 0));
}

    public void creaLivelloDue() {
        
        LvColor = Color.red;
        
        int groundY = 900;
        int step = 360; 

        // --- SECONDO 1-4: RISCALDAMENTO (Salti ritmati) ---
        // Serie di 4 spini singoli distanziati per dare ritmo
        for(int i = 1; i <= 4; i++) {
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * i+1, groundY));
        }

        // --- SECONDO 5-8: LA SCALA ALTA ---
        // Piattaforme che salgono e poi scendono bruscamente
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 6, groundY - 150));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7, groundY - 300));
        // Spino punitivo sotto la discesa
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 7, groundY));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 8, groundY - 450));

        // --- SECONDO 9-12: IL "SALTO DI FEDE" ---
        // Una piattaforma molto alta seguita da un vuoto con spini
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 300, 40, step * 9, groundY - 350));
        for(int j = 0; j < 5; j++) {
            // Tappeto di spini a terra mentre il player è in volo
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 9 + (j * 50), groundY));
        }

        // Atterraggio stretto
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, step * 12, groundY - 100));

        // --- SECONDO 13-15: FINALE TRIPLO ---
        int finaleX = step * 14;
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, finaleX, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, finaleX + 45, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, finaleX + 90, groundY));
    }
    
    public void creaLivelloTre() {
        
        LvColor = Color.magenta;
        
        int groundY = 900;
        int step = 360;
        
        // Riempiamo tutto il pavimento di spini: toccare terra = morte
        for(int i = 10; i < 60; i++) {
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, i * 100, groundY));
        }
        
        // --- INIZIO TRANQUILLO (Secondi 0-3) ---
        // Una zona sicura iniziale per stabilizzare il volo

        // --- OSTACOLI VOLANTI (Secondi 4-15) ---
        // Serie di piattaforme piccole e spini sospesi posizionati in modo asimmetrico

        // 4 Secondi: Ostacolo alto
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 80, 80, step * 4, groundY - 650));

        // 5.5 Secondi: Ostacolo basso (costringe a salire)
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 120, 40, (int)(step * 5.5), groundY - 250));

        // 7 Secondi: Il "Cancello" (una piattaforma sopra e una sotto)
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 60, 200, step * 7, groundY - 800)); // Sopra
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 60, 200, step * 7, groundY - 300)); // Sotto

        // 9 Secondi: Piattaforma minuscola con spino "sentinella"
        int xNove = step * 9;
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 50, 30, xNove, groundY - 450));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xNove + 6, groundY - 500));

        // 11-13 Secondi: Sequenza a zigzag veloce
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, step * 11, groundY - 600));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, (int)(step * 12.5), groundY - 300));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, step * 14, groundY - 600));

        // --- TRAGUARDO ---
        // Grande piattaforma finale per atterrare
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 600, 100, step * 16, groundY - 450));
    }
    
    public Color getLvColor() {
        return LvColor;
    }
    
    public ArrayList<Img> getSpini() {
        return spiniLivello;
    }
    
    public ArrayList<Img> getPiattaforme() {
        return piattaformeLivello;
    }
    
    public ArrayList<Img> getPortaliGravitaGiallo() {
        return portaliGravitaGialloLivello;
    }
    
    public ArrayList<Img> getPortaliGravitaBlu() {
        return portaliGravitaBluLivello;
    }
    public ArrayList<Img> getPortaliNavicella() {
        return portaliNavicellaLivello;
    }
    public ArrayList<Img> getPortaliCubo() {
        return portaliCuboLivello;
    }
    public ArrayList<Img> getFine() {
        return fine;
    }
}
