
package geometrydash;

import java.awt.Color;
import java.util.ArrayList;

public class Livello {
    private int lMSpino = 50, AMSpino = 50;
    private ArrayList<Img> spiniLivello = new ArrayList<>();
    private ArrayList<Img> piattaformeLivello = new ArrayList<>();
    private ArrayList<Img> portaliLivello = new ArrayList<>();
    private Color LvColor;
    public Livello(int numero) {
        switch(numero) {
            case 1: creaLivelloUno(); break;
            case 2: creaLivelloDue(); break; // Crea questi metodi
            case 3: creaLivelloTre(); break;
        }
    }
    
    public void creaLivelloUno() {
        
        LvColor = Color.blue;
        
        // VARIABILI DI COMODITÀ
        int groundY = 900; // La base dove poggiano gli spini
        int step = 360;    
        int offset = 1900;

        // --- SECONDO 1-3: INTRODUZIONE (Spini singoli e doppi) ---
        // Spino singolo a 2 secondi
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 2 + offset, groundY));
        
        //Esempio creazione portale
        //portaliLivello.add(new Img("/resources/images/anonimo.png", "portale", 50, 200, step * 2, groundY - 200));

        // Spino doppio a 3.5 secondi
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, (int)(step * 3.5) + offset, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, (int)(step * 3.5) + 50 + offset, groundY));

        // --- SECONDO 4-7: PIATTAFORME (Salti a mezz'aria) ---
        // Prima piattaforma sollevata
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 5 + offset, groundY - 120));
        // Spino sopra la piattaforma per cattiveria
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 5 + 50 + offset, groundY));

        // Successione di tre piattaforme (scale)
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7 + offset, groundY - 100));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7 + 300 + offset, groundY - 200));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7 + 600 + offset, groundY - 300));
        
        for(int i = 0; i < 15; i++) {
            int xNav = (int) (step * 6.4  + (i * 50));
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xNav + 200 + offset, groundY)); // Spino a testa in su
        }

        // --- SECONDO 8-10: TRIPLICE SPINO (Il classico di GD) ---
        int tripleX = step * 11;
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, tripleX + offset, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, tripleX + 45 + offset, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, tripleX + 90 + offset, groundY));

        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 14 + offset, groundY));

        // --- SECONDO 11-15: SEZIONE NAVICELLA (Tunnel) ---
        // Portale trasformazione (immaginario, lo mettiamo a 10.5s)
        // Qui dovresti chiamare trasformaNavicella quando il player tocca questa X

        // Tunnel stretto fatto di piattaforme sopra e sotto
        for(int i = 0; i < 10; i++) {
            int xNav = step * 13 + (i * 200);
            // Soffitto
            piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 200, 40, xNav + offset, groundY - 500));
            // Pavimento (più alto del solito per stringere il tunnel)
            piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 200, 40, xNav + offset, groundY - 100));

            // Ostacoli in mezzo al tunnel ogni 2 blocchi
            if(i % 2 == 0) {
                spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xNav + 200 + offset, groundY - 140)); // Spino a testa in su
            }
        }
    }
    
    public void creaLivelloDue() {
        
        LvColor = Color.red;
        
        int groundY = 900;
        int step = 360; 

        // --- SECONDO 1-4: RISCALDAMENTO (Salti ritmati) ---
        // Serie di 4 spini singoli distanziati per dare ritmo
        for(int i = 1; i <= 4; i++) {
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * i+1, groundY));
        }

        // --- SECONDO 5-8: LA SCALA ALTA ---
        // Piattaforme che salgono e poi scendono bruscamente
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 6, groundY - 150));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 7, groundY - 300));
        // Spino punitivo sotto la discesa
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 7, groundY));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 150, 40, step * 8, groundY - 450));

        // --- SECONDO 9-12: IL "SALTO DI FEDE" ---
        // Una piattaforma molto alta seguita da un vuoto con spini
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 300, 40, step * 9, groundY - 350));
        for(int j = 0; j < 5; j++) {
            // Tappeto di spini a terra mentre il player è in volo
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, step * 9 + (j * 50), groundY));
        }

        // Atterraggio stretto
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, step * 12, groundY - 100));

        // --- SECONDO 13-15: FINALE TRIPLO ---
        int finaleX = step * 14;
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, finaleX, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, finaleX + 45, groundY));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, finaleX + 90, groundY));
    }
    
    public void creaLivelloTre() {
        
        LvColor = Color.magenta;
        
        int groundY = 900;
        int step = 360;
        
        // Riempiamo tutto il pavimento di spini: toccare terra = morte
        for(int i = 10; i < 60; i++) {
            spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, i * 100, groundY));
        }
        
        // --- INIZIO TRANQUILLO (Secondi 0-3) ---
        // Una zona sicura iniziale per stabilizzare il volo

        // --- OSTACOLI VOLANTI (Secondi 4-15) ---
        // Serie di piattaforme piccole e spini sospesi posizionati in modo asimmetrico

        // 4 Secondi: Ostacolo alto
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 80, 80, step * 4, groundY - 650));

        // 5.5 Secondi: Ostacolo basso (costringe a salire)
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 120, 40, (int)(step * 5.5), groundY - 250));

        // 7 Secondi: Il "Cancello" (una piattaforma sopra e una sotto)
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 60, 200, step * 7, groundY - 800)); // Sopra
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 60, 200, step * 7, groundY - 300)); // Sotto

        // 9 Secondi: Piattaforma minuscola con spino "sentinella"
        int xNove = step * 9;
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 50, 30, xNove, groundY - 450));
        spiniLivello.add(new Img("/resources/images/spina.png", "spina", lMSpino, AMSpino, xNove + 6, groundY - 500));

        // 11-13 Secondi: Sequenza a zigzag veloce
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, step * 11, groundY - 600));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, (int)(step * 12.5), groundY - 300));
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 100, 40, step * 14, groundY - 600));

        // --- TRAGUARDO ---
        // Grande piattaforma finale per atterrare
        piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento", 600, 100, step * 16, groundY - 450));
    }
    
    public Color getLvColor() {
        return LvColor;
    }
    
    public ArrayList<Img> getSpini() {
        return spiniLivello;
    }
    
    public ArrayList<Img> getPiattaforme() {
        return piattaformeLivello;
    }
    
    public ArrayList<Img> getPortali() {
        return portaliLivello;
    }
}
