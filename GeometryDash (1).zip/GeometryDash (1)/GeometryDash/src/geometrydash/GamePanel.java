package geometrydash;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage; 
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;

class GamePanel extends JPanel {
    Img cubo;
    Img piattaforma;
    ArrayList<Img> spini;
    ArrayList<Img> piattaforme;
    ArrayList<Img> portali;
    Img titolo, sfondo;
    boolean isGameStarted = false;
    JButton giocaBtn = new JButton("GIOCA");
    JButton[] lvlButtons = new JButton[3];
    GeometryDash mainFrame; // Ci serve per far partire il timer nel Main
    
    java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    int screenW = (int) screenSize.getWidth();
    int screenH = (int) screenSize.getHeight();

    int btnW = 200;
    int btnH = 80;

    int x = (screenW / 2) - (btnW / 2);
    int y = (screenH / 2) - (btnH / 2);

    public GamePanel(GeometryDash frame, Img cubo, Img piattaforma, ArrayList<Img> spini, ArrayList<Img> piattaforme, ArrayList<Img> portali, Img titolo, Img sfondo) {        
        this.mainFrame = frame;
        this.cubo = cubo;
        this.piattaforma = piattaforma;
        this.spini = spini;
        this.piattaforme = piattaforme;
        this.portali = portali;
        this.titolo = titolo;
        this.sfondo = sfondo;
        
        this.setLayout(null);
        setBackground(Color.GRAY);

        giocaBtn.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
        giocaBtn.setBackground(java.awt.Color.WHITE);
        giocaBtn.setForeground(java.awt.Color.BLACK);
        giocaBtn.setFocusPainted(false);                                     // Toglie il rettangolino brutto al click
        giocaBtn.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK, 3));
        giocaBtn.setPreferredSize(new java.awt.Dimension(250, 80));
        giocaBtn.setBounds(x, y, btnW, btnH);
        giocaBtn.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
        add(giocaBtn);
        
        
        
        giocaBtn.addActionListener(e -> {
            remove(giocaBtn);
            mostraMenuLivelli();
            repaint();
        });
    }
    
    private void mostraMenuLivelli() {
        for (int i = 0; i < 3; i++) {
            int livelloNum = i + 1;
            lvlButtons[i] = new JButton("LIVELLO " + livelloNum);
            lvlButtons[i].setBounds(x, y + (i * 100), 200, 60);
            lvlButtons[i].setBackground(java.awt.Color.WHITE);
            lvlButtons[i].setForeground(java.awt.Color.BLACK);
            lvlButtons[i].setFocusPainted(false);
            lvlButtons[i].setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK, 3));
            lvlButtons[i].setPreferredSize(new java.awt.Dimension(250, 80));
            lvlButtons[i].setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            
            lvlButtons[i].addActionListener(e -> {
                selezionaLivello(livelloNum);
            });
            add(lvlButtons[i]);
        }
        revalidate();
    }
    
    private void selezionaLivello(int n) {
        for (JButton b : lvlButtons) {
            if (b != null) remove(b);
        }
        
        mainFrame.caricaLivelloSpecifico(n);
        isGameStarted = true; 
        this.revalidate();
        this.repaint();

        // Risaliamo al frame e riprendiamo il focus
        java.awt.Window parent = javax.swing.SwingUtilities.getWindowAncestor(this);
        if (parent != null) {
            parent.requestFocusInWindow();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Attiva l'antialiasing per una qualità migliore
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (!isGameStarted) {
            if (sfondo != null) {
                g2d.drawImage(sfondo.getBufferedImage(), 0, 0, getWidth(), getHeight(), null);
            }
            
            if (titolo != null) {
                int titoloX = (getWidth() - titolo.getW()) / 2;
                int titoloY = 200; 
                g2d.drawImage(titolo.getBufferedImage(), titoloX, titoloY, titolo.getW(), titolo.getH(), null);
            }
        } else {

            g2d.drawImage(piattaforma.getBufferedImage(), 
                    piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH(), null);

        
            for(Img spina : spini) {
                g2d.drawImage(spina.getBufferedImage(), 
                spina.getX(), spina.getY(), spina.getW(), spina.getH(), null);
            }

            for(Img piattaforma : piattaforme) {
                g2d.drawImage(piattaforma.getBufferedImage(), 
                piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH(), null);
            }
            
            for(Img portale : portali) {        
                g2d.drawImage(portale.getBufferedImage(), 
                portale.getX(), portale.getY(), portale.getW(), portale.getH(), null);
            }

            if(!cubo.getIsDeleted()) {
                AffineTransform old = g2d.getTransform();

                g2d.translate(cubo.getX() + cubo.getW() / 2, cubo.getY() + cubo.getH() / 2);
                g2d.rotate(Math.toRadians(cubo.getRotation()));
                BufferedImage imgCubo = cubo.getBufferedImage();
                g2d.drawImage(imgCubo, -cubo.getW() / 2, -cubo.getH() / 2, cubo.getW(), cubo.getH(), null);

                g2d.setTransform(old);
            }
        }
    }
    
    public Img getCubo() { return cubo; }
    
    public void deleteCubo() {
        cubo.delete();
    }
    
}