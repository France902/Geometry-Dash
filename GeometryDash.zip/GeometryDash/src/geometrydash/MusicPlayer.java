package geometrydash;

import javax.sound.sampled.*;
import java.io.IOException;
import java.net.URL;

/**
 * MusicPlayer centralizza la gestione audio del gioco.
 * Utilizza l'API standard Java Sound (javax.sound.sampled).
 * Gestisce due canali logici: uno per la musica (Clip persistente) 
 * e uno dinamico per gli effetti sonori.
 */
public class MusicPlayer {

    private Clip   musicClip;   // La linea audio dedicata alla musica di sottofondo
    private float  volume = 0.8f; // Range lineare: 0.0 (silenzio) a 1.0 (massimo)

    // ============================================================
    //  MUSICA DI SOTTOFONDO (Streaming Loop)
    // ============================================================

    /**
     * Inizializza e avvia una traccia audio in modalità loop infinito.
     * Implementa la pulizia automatica della traccia precedente per evitare memory leak.
     * * @param percorso Il path relativo alla risorsa audio (es: .wav)
     */
    public void avvia(String percorso) {
        ferma(); // Assicura che non ci siano sovrapposizioni di musica
        try {
            URL url = getClass().getResource(percorso);
            if (url == null) {
                System.out.println("MusicPlayer: file non trovato → " + percorso);
                return;
            }
            
            // Apertura dello stream audio e allocazione della linea (Clip)
            AudioInputStream stream = AudioSystem.getAudioInputStream(url);
            musicClip = AudioSystem.getClip();
            musicClip.open(stream);
            
            // Configurazione stato iniziale
            impostaVolume(musicClip, volume);
            musicClip.loop(Clip.LOOP_CONTINUOUSLY); // Imposta il loop infinito
            musicClip.start();
        } catch (UnsupportedAudioFileException | LineUnavailableException | IOException e) {
            System.out.println("MusicPlayer: errore avvio → " + e.getMessage());
        }
    }

    /** Ferma la riproduzione e dealloca le risorse della linea audio. */
    public void ferma() {
        if (musicClip != null && musicClip.isRunning()) {
            musicClip.stop();
            musicClip.close();
        }
        musicClip = null;
    }

    /** Sospende l'audio mantenendo il cursore di riproduzione sulla posizione attuale. */
    public void pausa() {
        if (musicClip != null && musicClip.isRunning())
            musicClip.stop();
    }

    /** Riprende l'esecuzione dal punto in cui era stata messa in pausa. */
    public void riprendi() {
        if (musicClip != null && !musicClip.isRunning())
            musicClip.start();
    }

    // ============================================================
    //  GESTIONE VOLUME (Logaritmica)
    // ============================================================

    /**
     * Aggiorna il valore globale del volume e lo applica istantaneamente alla traccia attiva.
     */
    public void setVolume(float v) {
        volume = Math.max(0f, Math.min(1f, v)); // Normalizzazione input
        if (musicClip != null) impostaVolume(musicClip, volume);
    }

    public float getVolume() { return volume; }

    /**
     * Converte il volume da scala lineare (0-1) a scala logaritmica (Decibel).
     * Questo è necessario perché l'orecchio umano percepisce l'intensità sonora logaritmicamente,
     * mentre i controlli hardware (MASTER_GAIN) operano in dB.
     * * Formula: dB = 20 * log10(volume)
     */
    private void impostaVolume(Clip clip, float v) {
        if (!clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) return;
        
        FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
        
        // Se il volume è 0, portiamo i decibel al minimo supportato (silenzio assoluto)
        float dB = (v == 0f) ? gain.getMinimum() : 20f * (float) Math.log10(v);
        
        // Clamp del valore per non eccedere i limiti fisici della scheda audio
        dB = Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB));
        gain.setValue(dB);
    }

    // ============================================================
    //  EFFETTI SONORI (Sincroni/Istantanei)
    // ============================================================

    /**
     * Riproduce un effetto (es: salto, morte) su una linea audio temporanea e indipendente.
     * Implementa un LineListener per chiudere automaticamente la linea al termine 
     * della riproduzione, liberando memoria.
     */
    public void riproduciEffetto(String percorso) {
        try {
            URL url = getClass().getResource(percorso);
            if (url == null) return;
            
            AudioInputStream stream = AudioSystem.getAudioInputStream(url);
            Clip effetto = AudioSystem.getClip();
            effetto.open(stream);
            
            impostaVolume(effetto, volume);
            effetto.start();
            
            // Auto-chiusura: quando l'audio finisce (STOP), la linea viene distrutta
            effetto.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) effetto.close();
            });
        } catch (UnsupportedAudioFileException | LineUnavailableException | IOException e) {
            System.out.println("MusicPlayer: errore effetto → " + e.getMessage());
        }
    }
}