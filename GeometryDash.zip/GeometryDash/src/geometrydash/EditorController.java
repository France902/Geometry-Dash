package geometrydash;

import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * EditorController gestisce la logica di creazione dei livelli personalizzati.
 * Si occupa di mappare i click del mouse sul piano di gioco e di coordinare
 * l'aggiunta di nuovi ostacoli o portali.
 */
public class EditorController {

    private final GamePanel          gamePanel;
    private final ArrayList<Livello> livelli;
    
    // Il tipo di oggetto attualmente "impugnato" dall'utente nell'editor
    private String tipoSelezionato = "spina";
    
    // Variabili per memorizzare le coordinate trasformate
    double xScalato, yScalato;

    public EditorController(GamePanel gamePanel, ArrayList<Livello> livelli) {
        this.gamePanel = gamePanel;
        this.livelli   = livelli;
    }

    // --- Getter e Setter per il tipo di oggetto selezionato ---
    public String getTipoSelezionato()          { return tipoSelezionato;       }
    public void   setTipoSelezionato(String t)  { tipoSelezionato = t;          }

    /**
     * Converte la posizione del click del mouse in coordinate del mondo di gioco,
     * applicando lo scaling e l'aggancio alla griglia (snapping).
     * * @param e L'evento del mouse (click).
     * @param scale Il fattore di scala corrente per adattarsi alla risoluzione dello schermo.
     */
    public void prendiCoordinateMouse(MouseEvent e, double scale) {
        // 1. Definisce la posizione reale dividendo per il fattore di scala del GamePanel
        xScalato = e.getX() / scale;
        yScalato = e.getY() / scale;

        // 2. Controllo Limite: impedisce di piazzare oggetti sotto il livello del suolo (Y=1100)
        if(yScalato + livelli.get(0).offsety >= 1100) {
            return; // Esci se il click è nell'area del pavimento
        }

        /*
         * 3. LOGICA DI SNAPPING (Aggancio alla griglia):
         * Per facilitare la costruzione, gli oggetti non vengono piazzati esattamente dove si clicca,
         * ma vengono "agganciati" a una griglia virtuale di 100x100 pixel.
         * La formula (Math.round(pos / 100) * 100) arrotonda al centinaio più vicino.
         */
        int xApprossimato = (int) (Math.round(xScalato / 100.0) * 100);
        int yApprossimato = (int) (Math.round(yScalato / 100.0) * 100); 

        // 4. Crea l'oggetto nel mondo di gioco
        creaElemento(tipoSelezionato, xApprossimato, yApprossimato);
    }

    /**
     * Invia l'ordine di creazione alla classe Livello e aggiorna la visualizzazione.
     */
    public void creaElemento(String tipo, int x, int y) {
        // Aggiunge l'oggetto fisicamente alla lista del livello corrente
        livelli.get(0).aggiungiElemento(tipo, x, y);
        
        // Sincronizza i dati con il GamePanel affinché il nuovo oggetto appaia a schermo
        gamePanel.spini = livelli.get(0).getSpini();
        
        // Richiede il ridisegno immediato del pannello
        gamePanel.repaint();
    }

    /**
     * Gestisce lo spostamento della visuale nell'editor (camera panning).
     * @param verso La direzione dello spostamento ("destra", "sinistra", ecc.).
     */
    public void spostaScena(String verso) {
        // Richiama il metodo di spostamento della classe Livello (offset -1 indica spostamento standard)
        livelli.get(0).spostaScena(verso, -1);
    }
}