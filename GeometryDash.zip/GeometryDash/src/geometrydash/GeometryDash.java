package geometrydash;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;

public class GeometryDash extends JFrame {

    // Strutture dati e componenti principali del gioco
    static ArrayList<Livello> livelli = new ArrayList<>();
    static GamePanel gamePanel;
    Timer gameLoop;
    private long lastTime = System.nanoTime();
    private volatile boolean running = true;
    boolean isEditing = false;
    
    private double smoothDt = 1.0 / 60.0;

    // Moduli specializzati per gestire le diverse meccaniche (Fisica, Input, Collisioni, ecc.)
    private final PlayerState state = new PlayerState();
    private final CollisionHandler collision = new CollisionHandler(state);
    private final MusicPlayer music;
    private final LevelManager levelManager;
    private final PhysicsEngine physics;
    private final PlayerTransformer transformer;
    private final EditorController editor;
    private final MovementHandler movement;
    private final InputController input;
    
    // Rettangoli di supporto per il calcolo delle collisioni
    private final Rectangle rect1 = new Rectangle();
    private final Rectangle rect2 = new Rectangle();

    private int frames = 0;
    private long lastFPSCheck = System.currentTimeMillis();

    static final int W = 100, H = 100;
    static int playerX = -100, playerY = 1050;
    
    Img cubo, pavimento;

    public GeometryDash() throws IOException {
        // Configurazione iniziale della finestra (JFrame)
        this.setTitle("Geometry Dash");
        this.setBackground(Color.BLACK);

        // Rilevamento dimensioni dello schermo per il ridimensionamento
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        java.awt.Dimension screen = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        int screenW = (int) screen.getWidth();
        int screenH = (int) screen.getHeight();

        // Caricamento asset grafici base
        cubo = new Img("/resources/images/cubo.png", "cubo", W, H, playerX, playerY, 0);
        pavimento = new Img("/resources/images/vuoto.png", "pavimento", screenW, 1000, 0, 1150, 0);
        Img titolo = new Img("/resources/images/Title.png", "titolo", 1500, 200, screenW / 2, screenH / 2, 0);
        Img sfondo = new Img("/resources/images/sfondo.png", "sfondo", screenW, screenH, 0, 0, 0);

        Livello lv = livelli.get(0);
        music = new MusicPlayer();
        levelManager = new LevelManager(livelli, music);
        
        // Inizializzazione del pannello di gioco principale con tutti gli elementi del livello
        gamePanel = new GamePanel(
            this, cubo, pavimento,
            lv.getSpini(), lv.getPiattaforme(),
            lv.getPortaliGravitaGiallo(), lv.getPortaliGravitaBlu(),
            lv.getPortaliNavicella(), lv.getPortaliCubo(),
            lv.getFine(), lv.getPadGialli(), lv.getOrbGialli(),
            lv.getBackgroundTexture(), lv.getGroundTexture(),
            titolo, sfondo
        );
        
        // Collegamento dei moduli di controllo
        physics = new PhysicsEngine(state, gamePanel, livelli);
        transformer = new PlayerTransformer(gamePanel, getClass().getClassLoader());
        levelManager.setGamePanel(gamePanel);
        editor = new EditorController(gamePanel, livelli);
        movement = new MovementHandler(state, gamePanel, physics, collision, transformer, livelli,
                            () -> fineLivello(cubo), this);
        
        gamePanel.setEditor(editor);
        gamePanel.setMusic(music);

        float[] contTimers = {0};
        input = new InputController(this, gamePanel, state, physics, editor);
        input.setup(cubo, pavimento, contTimers);

        // Impostazione modalità Fullscreen
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setUndecorated(true); 
        this.add(gamePanel);
        this.setVisible(true);

        if (gd.isFullScreenSupported()) {
            try {
                gd.setFullScreenWindow(this);
            } catch (Exception e) {
                this.setExtendedState(JFrame.MAXIMIZED_BOTH);
            }
        } else {
            this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        }

        this.revalidate();
        this.repaint();
        gamePanel.requestFocusInWindow(); 
        
        state.cuboCentrato = true;
        music.avvia("/resources/music/menuLoop.wav");
        
        // UI della percentuale di completamento
        JLabel percentuale = new JLabel();
        percentuale.setFont(new Font("Arial", Font.BOLD, 40));
        percentuale.setForeground(Color.WHITE);
        percentuale.setBounds(screenW / 2 - 100, 0, 150, 150);
        percentuale.setVisible(false);
        gamePanel.add(percentuale);
      

        gameLoop = new Timer(16, e -> {  // 16ms invece di 0 — più consistente su Windows
            long now = System.nanoTime();
            double rawDt = (now - lastTime) / 1_000_000_000.0;
            lastTime = now;

            // Media esponenziale: liscia i picchi senza introdurre lag
            // 0.1 = peso del frame attuale, 0.9 = peso della storia
            // Trasforma 0.025/0.033/0.025/0.033 in ~0.028/0.028/0.028
            smoothDt = smoothDt * 0.9 + rawDt * 0.1;
            double dt = Math.min(smoothDt, 0.033);

            if (gamePanel.isGameStarted) {
                updateGameLogic(dt, percentuale);
                gamePanel.repaint();
            }
        });
        gameLoop.start();
        
        creaAmbienteMenu();
    }
    
    private void updateGameLogic(double dt, JLabel percentuale) {
        if (!gamePanel.isGameStarted) return;
        
        if (livelli.isEmpty() || livelli.get(0) == null) return;

        // Logica Fisica
        if (!state.suspendPhysics) {
            rect1.setBounds((int)cubo.getX(), (int)cubo.getY(), cubo.getW(), cubo.getH());
            rect2.setBounds((int)pavimento.getX(), (int)pavimento.getY(), pavimento.getW(), pavimento.getH());

            if (!collision.checkCollisionGravity(cubo, pavimento, livelli.get(0).getPiattaforme(), rect1, rect2) 
                && !state.isJumping && !gamePanel.cubeHided) {

                physics.updatePhysics(cubo, pavimento, state.cont[0], dt);
                state.cont[0] += (250 * dt);
            } else {
                if (cubo.getRotation() != 90) state.cont[0] = 0;
                if (!state.isJumping) physics.raddrizzaCubo(cubo, dt);
            }
        }

        // Telecamera verticale
        if (cubo.getY() < (gamePanel.getBaseH() / 2.5f)) {
            float diff = Math.abs(cubo.getY() - (gamePanel.getBaseH() / 2.5f));
            livelli.get(0).spostaScena("sotto", diff);
            cubo.setY(cubo.getY() + diff);
            pavimento.setY(pavimento.getY() + diff);
        } else if (cubo.getY() > 1150) {
            float diff = Math.abs(cubo.getY() - 1150);
            livelli.get(0).spostaScena("sopra", diff);
            cubo.setY(cubo.getY() - diff);
            pavimento.setY(pavimento.getY() - diff);
        }

        // Movimento oggetti
        if (!state.cuboCentrato) {
            moveCubo(cubo, dt);
        } else {
            movement.updateMovement(
                livelli.get(0).getSpini(), livelli.get(0).getPiattaforme(),
                livelli.get(0).getPortaliGravitaGiallo(), livelli.get(0).getPortaliGravitaBlu(),
                livelli.get(0).getPortaliNavicella(), livelli.get(0).getPortaliCubo(),
                livelli.get(0).getFine(), livelli.get(0).getPadGialli(), livelli.get(0).getOrbGialli(),
                livelli.get(0).getBackgroundTexture(), livelli.get(0).getGroundTexture(),
                cubo, pavimento, dt, levelManager
            );
        }
        
        if (state.isJumping) {
            physics.updateJump(cubo, dt);
        }

        calcolaPercentuale();
        percentuale.setText(String.format("%.2f%%", percentualeCorrente));
        percentuale.setVisible(gamePanel.isGameStarted && !gamePanel.cubeHided);
        
    }
    
    float percentualeCorrente = 0;
    
    float ultimaPercentualeSalvata = -1f;

    private void calcolaPercentuale() {
        int lunghezzaLivello = livelli.get(0).getLunghezzaLivello();
        if (lunghezzaLivello == 0) return;

        percentualeCorrente = (float)(Math.round(
            Math.abs(livelli.get(0).getPosizionePrimoOggetto()) 
            / lunghezzaLivello * 10000.0) / 100.0);

        // Scrive su file solo se la percentuale è cambiata di almeno 1%
        // Prima: scriveva ogni frame (60 scritture/secondo su disco)
        if (Math.abs(percentualeCorrente - ultimaPercentualeSalvata) >= 1f) {
            levelManager.ScriviLivelloUfficiale();
            ultimaPercentualeSalvata = percentualeCorrente;
        }
    }

    // Animazione iniziale per far entrare il cubo in scena
    private void moveCubo(Img cubo, double dt) {
        float x = cubo.getX() + (float)(800.0 * dt);
        if (x > 800) { state.cuboCentrato = true; x = 800; levelManager.eseguiMusica();}
        cubo.setX(x);
    }
    
    // Metodi di interfaccia e utility per il controllo dei livelli
    public void creaAmbienteMenu() throws IOException {
        caricaLivelloSpecifico(-3);
        gamePanel.isGameStarted = true;
        gamePanel.revalidate();
        gamePanel.repaint();
    }
    
    public void setCuboCentrato(boolean cuboCentrato) { state.cuboCentrato = cuboCentrato; }
    public void setGravity(int gravity) { state.gravity = gravity; }
    public void setTipo(String tipo) { cubo.setTipo(tipo); }

    // Gestione della vittoria: ferma il gioco e avvia animazione finale
    public void fineLivello(Img cubo) {
        fermaGioco();
        livelli.get(0).setMigliorPrecentuale(100f);
        livelli.get(0).salvaMigliorPercentuale(levelManager.getLivelloSelezionato());

        int[] cont = {0};
        Timer anim = new Timer(16, e -> {
            cubo.setY(cubo.getY() - 4);
            cubo.setRotation(cubo.getRotation() + 5f);
            cont[0]++;
            gamePanel.repaint();
            if (cont[0] == 100) {
                cubo.setX(-100);
                cubo.setRotation(0);
                cubo.setY(860);
                state.cuboCentrato = false;
                gamePanel.creaMenuVittoria();
                gamePanel.isGameWin = true;
                ((Timer) e.getSource()).stop();
            }
        });
        anim.start();
    }

    // Delegation dei metodi al LevelManager
    public void caricaLivelloSpecifico(int n) throws IOException {
        livelli.clear();
        levelManager.caricaLivelloSpecifico(n);
        iniziaGioco();
        
    }
    
    public void caricaMenuEditor() throws IOException { levelManager.caricaMenuEditor(); }
    public void caricaAmbienteEditor(String id) throws IOException { levelManager.caricaAmbienteEditor(id); }
    public void rinominaLivello(String riga) { levelManager.rinominaLivello(riga); }
    public String getNomeLivello() { return levelManager.getNomeLivello(); }
    public Float getPecentuale() { return percentualeCorrente; }
    public Float getMigliorPercentuale() { return levelManager.getMigliorPercentuale(); }
    public void setMigliorPrecentuale(Float migliorPercentuale) { levelManager.setMigliorPrecentuale(migliorPercentuale); }
    
    public void esciLivello() throws IOException {
        fermaGioco();
        cubo.setX(-100);
        cubo.setY(playerY);
        cubo.setRotation(0);
        state.cuboCentrato = false;
        levelManager.esciLivello();
    }
    
    public void cambiaVolumeMusica(String verso) {
        if(verso.equals("sopra")) music.setVolume((music.getVolume() + 0.1f));
        else music.setVolume((music.getVolume() - 0.1f));
    }
    
    public void eseguiMusica() { levelManager.eseguiMusica(); }

    public static void creaLivelli() throws IOException {
        livelli.add(new Livello(-4, gamePanel, "Nessun id"));
    }

    // MAIN: Avvio applicazione con settaggi per l'accelerazione hardware grafica
    public static void main(String[] args) throws IOException {
        System.setProperty("sun.java2d.uiScale", "1.0");
        System.setProperty("sun.java2d.d3d", "true");
        System.setProperty("sun.java2d.transaccel", "true");
        System.setProperty("sun.java2d.ddforcevram","true");
        creaLivelli();
        new GeometryDash();
    }
    
    public void fermaGioco() {
        if (gameLoop != null) gameLoop.stop();
    }

    public void iniziaGioco() {
        lastTime = System.nanoTime(); // Resetta il clock per evitare un dt enorme al riavvio
        if (gameLoop != null) gameLoop.start();
    }
}