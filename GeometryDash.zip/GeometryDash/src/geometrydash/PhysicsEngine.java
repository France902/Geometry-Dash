package geometrydash;

import javax.swing.Timer;
import java.util.ArrayList;
import javax.swing.SwingUtilities;

/**
 * PhysicsEngine gestisce le forze fisiche applicate al giocatore.
 * Calcola la velocità di caduta, la parabola del salto e la rotazione
 * procedurale del cubo basata sul tempo.
 */
public class PhysicsEngine {

    private final PlayerState       state;
    private final GamePanel         gamePanel;
    private final ArrayList<Livello> livelli;
    
    Timer jumpTimer;
    private Thread jumpThread; // Thread separato per non bloccare il rendering durante il salto

    public PhysicsEngine(PlayerState state, GamePanel gamePanel, ArrayList<Livello> livelli) {
        this.state     = state;
        this.gamePanel = gamePanel;
        this.livelli   = livelli;
    }

    /**
     * Aggiorna la posizione verticale e la rotazione ad ogni frame.
     * @param deltaTime Tempo trascorso dall'ultimo frame (per rendere il gioco fluido a qualsiasi FPS).
     */
    public void updatePhysics(Img cubo, Img pavimento, float cont, double deltaTime) {
        float currentY   = cubo.getY();
        float rotation   = cubo.getRotation();
        float frameScale = 125.0f; // Scaler per normalizzare il movimento rispetto al tempo

        // --- GESTIONE ROTAZIONE ---
        if (cubo.getTipo().equals("cubo")) {
            // Il cubo ruota costantemente mentre cade/salta
            rotation += (3.5f * frameScale) * deltaTime;
            if (rotation >= 360) rotation -= 360;
            cubo.setRotation(rotation);
            // Calcolo velocità di caduta (accelerazione costante)
            state.speed = 0.3f * cont;
        } else {
            // La navicella ruota leggermente verso il basso durante la caduta
            rotation += (1f * frameScale) * deltaTime;
            if (rotation >= 40) rotation = 40; // Limite massimo di rotazione
            cubo.setRotation(rotation);
            state.speed = 0.0867f * cont;
        }

        // --- GESTIONE CADUTA E GRAVITÀ ---
        if (state.speed > 30) state.speed = 30; // Terminal Velocity (velocità massima di caduta)
        
        // Calcolo della nuova Y: Y = Y + (Velocità * DirezioneGravità * Tempo)
        currentY += (state.speed * state.gravity * frameScale) * deltaTime ;
        cubo.setY(currentY);
    }

    /**
     * Ruota il cubo verso l'angolo retto più vicino (0, 90, 180, 270) 
     * quando atterra, per simulare l'impatto perfetto sul suolo.
     */
    public void raddrizzaCubo(Img cubo, double dt) {
        float[] rotation     = {cubo.getRotation()};
        int[]   closerAngle  = {0};
        int     index        = 0;

        // Calcola la distanza tra la rotazione attuale e i 4 angoli cardinali
        float[] diff = {
            Math.abs(0   - rotation[0]),
            Math.abs(90  - rotation[0]),
            Math.abs(180 - rotation[0]),
            Math.abs(270 - rotation[0]),
            Math.abs(360 - rotation[0])
        };
        float min = diff[0];
        for (int i = 1; i < 4; i++) {
            if (min > diff[i]) { index = i; min = diff[i]; }
        }
        closerAngle[0] = switch (index) {
            case 1  -> 90;
            case 2  -> 180;
            case 3  -> 270;
            case 4  -> 360;
            default -> 0;
        };

        float velocitaRaddrizzamento = (float)(600.0 * dt); // 600°/sec invece di 6°/frame
        int verso = (closerAngle[0] - rotation[0] >= 0) ? 1 : -1;
        if (Math.abs(closerAngle[0] - rotation[0]) > velocitaRaddrizzamento)
            rotation[0] += velocitaRaddrizzamento * verso;
        else
            rotation[0] = closerAngle[0];

        cubo.setRotation(rotation[0]);
    }

    /**
     * Gestisce la forza impulsiva del salto. 
     * Utilizza un Thread separato per gestire l'ascesa del giocatore in modo asincrono.
     */
    // Rimuovi jumpThread e jumpTimer completamente

    public void saltaPlayer(Img cubo, String stato, Img pavimento) {
        if (state.isJumping) return;
        state.jumpPotenziato = "potenziato".equals(stato);
        state.contJump[0] = 0;
        state.isJumping = true;
    }

    // Chiamato ogni frame da updateGameLogic in GeometryDash
    public void updateJump(Img cubo, double dt) {
        if (!state.isJumping) return;

        float limit = state.jumpPotenziato ? 20f : 12f;
        float forza = state.jumpPotenziato ? 35f : 27f;

        // Normalizza rispetto ai 16ms del vecchio Thread
        float steps = (float)(dt / 0.016);

        cubo.setRotation(cubo.getRotation() + 6f * steps);

        float dy = (forza - state.contJump[0]) * state.gravity * steps;
        cubo.setY(cubo.getY() - dy);
        state.contJump[0] += steps;

        if (state.contJump[0] >= limit) {
            state.isJumping = false;
            state.cont[0] = -(int)state.contJump[0];
            state.contJump[0] = 0;
        }
    }

    /**
     * Logica di volo per la modalità Navicella (Ship).
     * Quando il tasto è premuto, contrasta la gravità portando il giocatore verso l'alto.
     */
    public void muoviNavicella(Img navicella, float cont) {
        sospendiFisica(); // Blocca la caduta standard durante la spinta attiva
        float rotation = navicella.getRotation() - 3f;
        if (rotation <= -40) rotation = -40; // Inclinazione muso verso l'alto
        navicella.setRotation(rotation);
        navicella.setY(navicella.getY() - (3 + cont));
    }

    public void sospendiFisica()   { state.suspendPhysics = true;  }
    public void ripristinaFisica() { state.suspendPhysics = false; }

    /**
     * Gestisce l'inversione della gravità tramite portali.
     * @param tipo "giallo" inverte la gravità (soffitto), "blu" la ripristina (suolo).
     */
    public void cambiaGravita(String tipo) {
        state.gravity  = "giallo".equals(tipo) ? -1 : 1;
        state.cont[0]  = -10; // Evita accelerazioni brusche durante il cambio
        state.speed    = 0;
    }
}