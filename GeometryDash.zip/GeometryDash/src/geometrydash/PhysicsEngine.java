package geometrydash;

import javax.swing.Timer;
import java.util.ArrayList;
import javax.swing.SwingUtilities;

/**
 * PhysicsEngine gestisce le forze fisiche applicate al giocatore.
 * Calcola la velocità di caduta, la parabola del salto e la rotazione
 * procedurale del cubo basata sul tempo.
 */
public class PhysicsEngine {

    private final PlayerState       state;
    private final GamePanel         gamePanel;
    private final ArrayList<Livello> livelli;
    
    Timer jumpTimer;
    private Thread jumpThread; // Thread separato per non bloccare il rendering durante il salto

    public PhysicsEngine(PlayerState state, GamePanel gamePanel, ArrayList<Livello> livelli) {
        this.state     = state;
        this.gamePanel = gamePanel;
        this.livelli   = livelli;
    }

    /**
     * Aggiorna la posizione verticale e la rotazione ad ogni frame.
     * @param deltaTime Tempo trascorso dall'ultimo frame (per rendere il gioco fluido a qualsiasi FPS).
     */
    public void updatePhysics(Img cubo, Img pavimento, int cont, double deltaTime) {
        float currentY   = cubo.getY();
        float rotation   = cubo.getRotation();
        float frameScale = 125.0f; // Scaler per normalizzare il movimento rispetto al tempo

        // --- GESTIONE ROTAZIONE ---
        if (cubo.getTipo().equals("cubo")) {
            // Il cubo ruota costantemente mentre cade/salta
            rotation += (3.5f * frameScale) * deltaTime;
            if (rotation >= 360) rotation -= 360;
            cubo.setRotation(rotation);
            // Calcolo velocità di caduta (accelerazione costante)
            state.speed = 0.3f * cont;
        } else {
            // La navicella ruota leggermente verso il basso durante la caduta
            rotation += (1f * frameScale) * deltaTime;
            if (rotation >= 40) rotation = 40; // Limite massimo di rotazione
            cubo.setRotation(rotation);
            state.speed = 0.0867f * cont;
        }

        // --- GESTIONE CADUTA E GRAVITÀ ---
        if (state.speed > 30) state.speed = 30; // Terminal Velocity (velocità massima di caduta)
        
        // Calcolo della nuova Y: Y = Y + (Velocità * DirezioneGravità * Tempo)
        currentY += (state.speed * state.gravity * frameScale) * deltaTime;
        cubo.setY(currentY);
    }

    /**
     * Ruota il cubo verso l'angolo retto più vicino (0, 90, 180, 270) 
     * quando atterra, per simulare l'impatto perfetto sul suolo.
     */
    public void raddrizzaCubo(Img cubo) {
        float[] rotation     = {cubo.getRotation()};
        int[]   closerAngle  = {0};
        int     index        = 0;

        // Calcola la distanza tra la rotazione attuale e i 4 angoli cardinali
        float[] diff = {
            Math.abs(0   - rotation[0]),
            Math.abs(90  - rotation[0]),
            Math.abs(180 - rotation[0]),
            Math.abs(270 - rotation[0]),
            Math.abs(360 - rotation[0])
        };
        float min = diff[0];
        for (int i = 1; i < 4; i++) {
            if (min > diff[i]) { index = i; min = diff[i]; }
        }
        closerAngle[0] = switch (index) {
            case 1  -> 90;
            case 2  -> 180;
            case 3  -> 270;
            case 4  -> 360;
            default -> 0;
        };

        // Ruota gradualmente di 6 gradi per frame fino al raggiungimento dell'angolo
        int verso = (closerAngle[0] - rotation[0] >= 0) ? 1 : -1;
        if (Math.abs(closerAngle[0] - rotation[0]) > 6)
            rotation[0] += 6 * verso;
        else
            rotation[0] = closerAngle[0];

        cubo.setRotation(rotation[0]);
    }

    /**
     * Gestisce la forza impulsiva del salto. 
     * Utilizza un Thread separato per gestire l'ascesa del giocatore in modo asincrono.
     */
    public void saltaPlayer(Img cubo, String stato, Img pavimento) {
        if (jumpThread != null && jumpThread.isAlive()) jumpThread.interrupt();
        
        jumpThread = new Thread(() -> {
            boolean potenziato = "potenziato".equals(stato); // Se usato su un Jump Pad (Giallo)
            float limit = potenziato ? 20 : 12; // Durata della fase di ascesa

            while (!Thread.currentThread().isInterrupted()) {
                if (!state.isJumping) {
                    Thread.currentThread().interrupt();
                    break;
                }

                // Esegue l'aggiornamento grafico sul thread di Swing (EDT)
                SwingUtilities.invokeLater(() -> {
                    float currentY = cubo.getY();
                    float rotation = cubo.getRotation();

                    rotation += 6; // Ruota durante il salto
                    cubo.setRotation(rotation);
                    
                    // Formula del salto: spinta verso l'alto attenuata dal contatore progressivo
                    currentY -= ((potenziato ? 35 : 25) - state.contJump[0]) * state.gravity;
                    cubo.setY(currentY);
                    state.contJump[0] += 1f;

                    // Fine della fase di spinta del salto
                    if (state.contJump[0] >= limit) {
                        state.isJumping   = false;
                        state.cont[0]     = (int) state.contJump[0] * -1; // Prepara la fase di caduta
                        state.contJump[0] = 0;
                        jumpThread.interrupt();
                    }
                });

                try {
                    Thread.sleep(16); // Circa 60 FPS per il calcolo della fisica
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });

        jumpThread.setDaemon(true); 
        jumpThread.setName("jump-thread");
        jumpThread.start();
    }

    /**
     * Logica di volo per la modalità Navicella (Ship).
     * Quando il tasto è premuto, contrasta la gravità portando il giocatore verso l'alto.
     */
    public void muoviNavicella(Img navicella, float cont) {
        sospendiFisica(); // Blocca la caduta standard durante la spinta attiva
        float rotation = navicella.getRotation() - 3f;
        if (rotation <= -40) rotation = -40; // Inclinazione muso verso l'alto
        navicella.setRotation(rotation);
        navicella.setY(navicella.getY() - (3 + cont));
    }

    public void sospendiFisica()   { state.suspendPhysics = true;  }
    public void ripristinaFisica() { state.suspendPhysics = false; }

    /**
     * Gestisce l'inversione della gravità tramite portali.
     * @param tipo "giallo" inverte la gravità (soffitto), "blu" la ripristina (suolo).
     */
    public void cambiaGravita(String tipo) {
        state.gravity  = "giallo".equals(tipo) ? -1 : 1;
        state.cont[0]  = -10; // Evita accelerazioni brusche durante il cambio
        state.speed    = 0;
    }
}