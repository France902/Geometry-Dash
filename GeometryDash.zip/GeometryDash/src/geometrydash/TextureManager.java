package geometrydash;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

/**
 * TextureManager ottimizza il caricamento e la gestione delle immagini.
 * Invece di caricare la stessa immagine più volte, la mantiene in una cache statica
 * già scalata alle dimensioni corrette, riducendo il carico sulla CPU e sulla RAM.
 */
public class TextureManager {
    
    /** * CACHE: Mappa che associa una chiave (percorso + dimensioni) a una BufferedImage.
     * Impedisce la ridondanza dei dati in memoria.
     */
    private static final Map<String, BufferedImage> cache = new HashMap<>();

    /**
     * Recupera una texture dalla cache o la carica dal disco se non presente.
     * * @param path Percorso della risorsa (es. "/resources/images/cubo.png")
     * @param W Larghezza desiderata
     * @param H Altezza desiderata
     * @return La BufferedImage scalata e pronta per il rendering
     */
    public static BufferedImage getTexture(String path, int W, int H) {
        // La chiave combina percorso e dimensioni per distinguere versioni diverse dello stesso asset
        String key = path + "_" + W + "x" + H;

        if (!cache.containsKey(key)) {
            try {
                URL imgUrl = TextureManager.class.getResource(path);
                if (imgUrl == null) {
                    System.err.println("Immagine non trovata: " + path);
                    return null;
                }

                // Caricamento dell'immagine originale
                BufferedImage originale = ImageIO.read(imgUrl);
                
                // Ridimensionamento immediato: l'immagine viene salvata in cache
                // già alle dimensioni finali del gioco per evitare scaling in real-time
                BufferedImage scalata = resize(originale, W, H);
                cache.put(key, scalata);
                
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
        return cache.get(key);
    }

    /**
     * Esegue il ridimensionamento dell'immagine utilizzando algoritmi di alta qualità.
     * Crea un'immagine compatibile con la configurazione dello schermo per massimizzare
     * l'accelerazione hardware.
     */
    private static BufferedImage resize(BufferedImage img, int newW, int newH) {
        // Ottiene la configurazione dello schermo corrente (Bit depth, Color model)
        java.awt.GraphicsConfiguration config = java.awt.GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getDefaultScreenDevice()
                .getDefaultConfiguration();

        // Crea una BufferedImage "Accelerata": il sistema cercherà di caricarla in VRAM
        BufferedImage dimg = config.createCompatibleImage(newW, newH, java.awt.Transparency.TRANSLUCENT);
        Graphics2D g2d = dimg.createGraphics();

        // Configurazione della qualità di campionamento (Bilineare per un buon compromesso velocità/qualità)
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Disegna l'immagine originale sul buffer ridimensionato
        g2d.drawImage(img, 0, 0, newW, newH, null);
        g2d.dispose(); // Rilascia le risorse del contesto grafico

        return dimg;
    }
}