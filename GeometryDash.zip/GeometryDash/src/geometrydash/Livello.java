package geometrydash;

import java.awt.Color;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javax.swing.Timer;

/**
 * ============================================================
 *  LIVELLO.JAVA — Definizione e costruzione dei livelli di gioco
 * ============================================================
 *
 *  Questa classe contiene le posizioni di ogni spina, piattaforma, 
 *  portale e obiettivo per ognuno dei tre livelli disponibili.
 *
 *  Il pattern usato è un semplice factory via switch nel costruttore:
 *  si passa il numero del livello e viene chiamato il metodo
 *  di costruzione corrispondente (creaLivelloUno/Due/Tre).
 *
 *  COORDINATE:
 *  Tutto è espresso nel sistema virtuale 2560×1440.
 *  Le posizioni X sono calcolate con la formula:
 *    step * N + offset
 *  dove "step" è la distanza base tra gli elementi (660px per i livelli
 *  1 e 2, 360px per il livello 3 più compatto) e "offset" spinge
 *  gli ostacoli fuori dallo schermo inizialmente.

 */
public final class Livello {

    // ============================================================
    //  DIMENSIONI DEFAULT DELLE SPINE
    // ============================================================

    /**
     * lMSpino (larghezza) e AMSpino (altezza) definiscono le dimensioni
     * in pixel virtuali di ogni spina (e per estensione di ogni pad/orb,
     * che riusano queste costanti per comodità).
     * Valore fisso: 50×50 px.
     */
    // Dimensioni predefinite (Larghezza, Altezza)
    private int lMSpino = 100, AMSpino = 100;
    private int lMPiattaforma = 100, AMPiattaforma = 100;
    private int lMPortale = 80, AMPortale = 150; // I portali sono solitamente più alti
    private int lMPad = 50, AMPad = 20;          // I pad sono bassi e larghi
    private int lMOrb = 40, AMOrb = 40;          // Gli orb sono piccoli e circolari
    private int lMFine = 60, AMFine = 1000;       // Il trigger di fine è solitamente un'asta o un'area alta
    private int tempoTotaleLivello = 0;
    int offsetx = 0, offsety = 0;
    private String idLivelloPersonalizzato;
    private String titoloMusica;
    private Float migliorPercentuale;
    
    List<String> righe = new ArrayList<>(Arrays.asList());
    
    List<List<String>> livelliPersonalizzati = new ArrayList<>();
    GamePanel gamePanel;

    // ============================================================
    //  LISTE DEGLI OGGETTI DEL LIVELLO
    // ============================================================

    /** Spine: gli ostacoli principali. Uccidono al contatto (hitbox ridotta del 12px). */
    private ArrayList<Img> spiniLivello = new ArrayList<>();

    /** Piattaforme su cui il player può atterrare, o contro cui può morire lateralmente. */
    private ArrayList<Img> piattaformeLivello = new ArrayList<>();

    /** Portali gravità giallo: invertono la gravità (gravity = -1, player "cade" verso l'alto). */
    private ArrayList<Img> portaliGravitaGialloLivello = new ArrayList<>();

    /** Portali gravità blu: ripristinano la gravità normale (gravity = +1). */
    private ArrayList<Img> portaliGravitaBluLivello = new ArrayList<>();

    /** Portali navicella: trasformano il player nella modalità volo. */
    private ArrayList<Img> portaliNavicellaLivello = new ArrayList<>();

    /** Portali cubo: riportano il player alla modalità cubo standard. */
    private ArrayList<Img> portaliCuboLivello = new ArrayList<>();

    /** Pad gialli: al contatto eseguono un salto potenziato (saltaPlayer "potenziato"). */
    private ArrayList<Img> padGialliLivello = new ArrayList<>();

    /** Orb gialli: il player può saltare mentre li tocca, come se fossero il suolo. */
    private ArrayList<Img> orbGialliLivello = new ArrayList<>();
    
    /** Sezione decorativa: texture sfondo. */
    private ArrayList<Img> backgroundTexture = new ArrayList<>();
    
     /** texture pavimento. */
    private ArrayList<Img> groundTexture = new ArrayList<>();
    
    private ArrayList<Img> menuLivelloEditor = new ArrayList<>();
    
    private ArrayList<Img> stringheLivelli = new ArrayList<>();
    
    private ArrayList<Img> livelliPersonalizzatiButtons = new ArrayList<>();
    

    /**
     * Oggetto marcatore di fine livello.
     * Al contatto con il player, avvia la sequenza di vittoria (fineLivello()).
     * È una lista per uniformità con gli altri oggetti, ma contiene sempre un solo elemento.
     */
    private ArrayList<Img> fine = new ArrayList<>();

    /** Colore di sfondo del livello (usato da GamePanel.setBackground()). */
    private Color LvColor = Color.BLACK;
    
    

    // ============================================================
    //  COSTRUTTORE
    // ============================================================

    /**
     * Crea il livello corrispondente al numero passato.
     * Chiama il metodo di costruzione specifico via switch.
     * Se il numero non corrisponde a nessun livello, le liste restano vuote
     * (nessun ostacolo, livello percorribile a vuoto).
     *
     * @param numero Il numero del livello da creare.
     */
    
    private Path PATH;
    public Livello(int numero, GamePanel gamePanel, String id) throws IOException {
        this.gamePanel = gamePanel;
        
        switch (numero) {
            case -3 -> caricaAmbienteMenu();
            
            case -2 -> creaAmbienteEditor(id);
            
            case -1 -> creaMenuEditor();
            
            case 1 -> creaLivelloUno();
            
            case 2 -> creaLivelloDue();
            
            case 3 -> creaLivelloTre();
            
        }
        
        if(numero != -1) {
            createBackgroundTexture();
            createGroundTexture();
        }
        
    }
    
    
    Color currentColor;
    Timer timer;
    
    public void caricaAmbienteMenu() {
        LvColor = Color.BLUE;
        gamePanel.cubeHided = true;
        
        Color[] colors = {Color.blue.darker(), Color.RED, Color.GREEN};
        currentColor = colors[0];
        
        Random rand = new Random();  
        
        timer = new Timer(5000, e -> {
            if(!gamePanel.cubeHided) timer.stop();
            else {
                int numCasuale;
                do {
                    numCasuale = rand.nextInt(3);
                } while(colors[numCasuale] == currentColor);

                currentColor = colors[numCasuale]; 
                LvColor = currentColor;
                for(Img texture : backgroundTexture) {
                    if (texture.getX() > (gamePanel.getBaseW() + 500) && texture.getX() > -200) continue;
                    texture.setColor(LvColor.darker());
                } 
                groundTexture.get(0).setColor(LvColor.darker());
                gamePanel.setBackground(LvColor);
            }
            

        });
        
        timer.start();
    }
    
    public void stopTimer() {
        timer.stop();
    }
    
    public void creaMenuEditor() throws IOException {
        LvColor = Color.blue;
        PATH = Paths.get("livelliPersonalizzati.csv");
        righe = Files.readAllLines(PATH);
        caricaLivelliPersonalizzati(righe);   
        createLVMenuEditor();
        visualizzaMenuLivelliEditor();
        visualizzaStringheLivelli();
        visualizzaLivelliPersonalizzatiButtons();
    }
    
    public void creaAmbienteEditor(String id) throws IOException {
        idLivelloPersonalizzato = id;
        livelliPersonalizzati.clear();
        menuLivelloEditor.clear();
        gamePanel.setLvMenuEditor(menuLivelloEditor);
        LvColor = Color.blue;
        PATH = Paths.get("livelliPersonalizzati.csv");
        righe = Files.readAllLines(PATH);
        caricaLivelliPersonalizzati(righe);   
        caricaImmagini(livelliPersonalizzati.get(Integer.parseInt(id)));
    }
    
    public void caricaLivelliPersonalizzati(List<String> righe) {
        int i, j;
        for(i=0;i<righe.size();i++) {
            if(righe.get(i).startsWith("#")) {
                livelliPersonalizzati.add(new ArrayList<>());
                for(j=i;j<righe.size();j++) {
                    if(righe.get(j).startsWith("#") && j != i) break;
                    livelliPersonalizzati.getLast().add(righe.get(j));
                }
            }
        }
        
        
        
    }
    
    public void rinominaLivello(String riga, String id) {
        livelliPersonalizzati.get(Integer.parseInt(id)).set(0, riga);
        scriviLivello();
    }
    
    
    
    public String getNomeLivello(String id) {
        
        return livelliPersonalizzati.get(Integer.parseInt(id)).get(0).substring(1);
    }
    
    public void visualizzaMenuLivelliEditor() {
        gamePanel.setLvMenuEditor(menuLivelloEditor);
    }
    
    public void visualizzaStringheLivelli() {
        gamePanel.setStringheLivelli(stringheLivelli);
    }

    public void visualizzaLivelliPersonalizzatiButtons() {
        gamePanel.setLivelliPersonalizzatiButtons(livelliPersonalizzatiButtons);
    }
    
    public void aggiungiElemento(String tipo, int x, int y) {
       switch(tipo) {
            case "spina" -> {
                spiniLivello.add(new Img("/resources/images/spina.png", "spina",
                        lMSpino, AMSpino, x - (lMSpino / 2), y - (AMSpino / 2), 0));
                scriviLivello(spiniLivello.getLast());
            }

            case "piattaforma" -> {
                piattaformeLivello.add(new Img("/resources/images/piattaforma.png", "pavimento",
                        lMPiattaforma, AMPiattaforma, x - (lMPiattaforma / 2), y - (AMPiattaforma / 2), 0));
                scriviLivello(piattaformeLivello.getLast());
            }

            case "portaleGravitaGiallo" -> {
                portaliGravitaGialloLivello.add(new Img("/resources/images/portaleGiallo.png", "portaleGravitaGiallo",
                        lMPortale, AMPortale, x - (lMPortale / 2), y - (AMPortale / 2), 0));
                scriviLivello(portaliGravitaGialloLivello.getLast());
            }

            case "portaleGravitaBlu" -> {
                portaliGravitaBluLivello.add(new Img("/resources/images/portaleBlu.png", "portaleGravitaBlu",
                        lMPortale, AMPortale, x - (lMPortale / 2), y - (AMPortale / 2), 0));
                scriviLivello(portaliGravitaBluLivello.getLast());
            }

            case "portaleNavicella" -> {
                portaliNavicellaLivello.add(new Img("/resources/images/portaleNavicella.png", "portaleNavicella",
                        lMPortale, AMPortale, x - (lMPortale / 2), y - (AMPortale / 2), 0));
                scriviLivello(portaliNavicellaLivello.getLast());
            }

            case "portaleCubo" -> {
                portaliCuboLivello.add(new Img("/resources/images/portaleCubo.png", "portaleCubo",
                        lMPortale, AMPortale, x - (lMPortale / 2), y - (AMPortale / 2), 0));
                scriviLivello(portaliCuboLivello.getLast());
            }

            case "padGiallo" -> {
                padGialliLivello.add(new Img("/resources/images/padGiallo.png", "padGiallo",
                        lMPad, AMPad, x - (lMPad / 2), y - (AMPad / 2), 0));
                scriviLivello(padGialliLivello.getLast());
            }

            case "orbGiallo" -> {
                orbGialliLivello.add(new Img("/resources/images/orbGiallo.png", "orbGiallo",
                        lMOrb, AMOrb, x - (lMOrb / 2), y - (AMOrb / 2), 0));
                scriviLivello(orbGialliLivello.getLast());
            }

            case "fine" -> {
                fine.add(new Img("/resources/images/fine.png", "fine",
                        lMFine, AMFine, x - (lMFine / 2), y - (AMFine / 2), 0));
                scriviLivello(fine.getLast());
            }
        }
    }
    
    
    
    public void scriviLivello(Img img) {
        String cartellaEseguibile = System.getProperty("user.dir");
        PATH = Paths.get(cartellaEseguibile, "livelliPersonalizzati.csv");
    
        String riga = String.format("%s,%s,%d,%d,%.0f,%.0f,%.0f", 
            img.getUrl(true), 
            img.getTipo(), 
            img.getW(), 
            img.getH(), 
            img.getX() + offsetx, 
            img.getY() + offsety, 
            img.getRotation()
        );
        
        livelliPersonalizzati.get(Integer.parseInt(idLivelloPersonalizzato)).add(riga);
        
        righe.clear();
        
        for(List<String> livello : livelliPersonalizzati) {
            for(String rg : livello) {
                // Aggiungi la riga solo se non è vuota o composta solo da spazi
                if (rg != null && !rg.trim().isEmpty()) {
                    righe.add(rg);
                }
            }
        }
        try {
            Files.write(PATH, righe);
        } catch (IOException e) {
        }
    }
    
    public void scriviLivello() {
        String cartellaEseguibile = System.getProperty("user.dir");
        PATH = Paths.get(cartellaEseguibile, "livelliPersonalizzati.csv");
        
        righe.clear();
        for(List<String> livello : livelliPersonalizzati) {
            for(String rg : livello) {
                // Aggiungi la riga solo se non è vuota o composta solo da spazi
                if (rg != null && !rg.trim().isEmpty()) {
                    righe.add(rg);
                }
            }
        }
        try {
            Files.write(PATH, righe);
        } catch (IOException e) {
        }
    }
    
    public void salvaMigliorPercentuale(int numeroLivello) {
        String cartellaEseguibile = System.getProperty("user.dir");
        String nomeFile;

        switch (numeroLivello) {
            case 1 -> nomeFile = "livello1.csv";
            case 2 -> nomeFile = "livello2.csv";
            case 3 -> nomeFile = "livello3.csv";
            default -> { return; }
        }

        PATH = Paths.get(cartellaEseguibile, nomeFile);

        try {
            List<String> righeFile = Files.readAllLines(PATH);
            boolean trovata = false;

            for (int i = 0; i < righeFile.size(); i++) {
                if (righeFile.get(i).startsWith("perc,")) {
                    righeFile.set(i, "perc," + migliorPercentuale); // aggiorna la riga esistente
                    trovata = true;
                    break;
                }
            }

            if (!trovata) righeFile.add("perc," + migliorPercentuale); // aggiunge se non esiste

            Files.write(PATH, righeFile);
        } catch (IOException e) {
            System.err.println("Errore salvataggio percentuale: " + e.getMessage());
        }
    }
    
    // ============================================================
    //  LIVELLI UFFICIALI
    // ============================================================

    public void creaLivelloUno() throws IOException {
        LvColor = Color.blue;
        PATH = Paths.get("livello1.csv");
        List<String> righe = Files.readAllLines(PATH);
        caricaImmagini(righe);
        calcolaLunghezzaTotale(righe);
    }
    
    
    
    public void creaLivelloDue() throws IOException {
        LvColor = Color.cyan;
        PATH = Paths.get("livello2.csv");
        List<String> righe = Files.readAllLines(PATH);
        caricaImmagini(righe);
        calcolaLunghezzaTotale(righe);
    }
    
    public void creaLivelloTre() throws IOException {
        LvColor = Color.red;
        PATH = Paths.get("livello3.csv");
        righe = Files.readAllLines(PATH);
        caricaImmagini(righe);
        calcolaLunghezzaTotale(righe);
    }
    
    public void caricaImmagini(List<String> righe) {
        for (String riga : righe) {
            String[] campi = riga.split(",");
            if(campi[0].endsWith(".png")) {
                switch(campi[1]) {
                    case "spina" -> spiniLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "pavimento" -> piattaformeLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "portaleGravitaGiallo" -> portaliGravitaGialloLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "portaleGravitaBlu" -> portaliGravitaBluLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "portaleNavicella" -> portaliNavicellaLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "portaleCubo" -> portaliCuboLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "padGiallo" -> padGialliLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "orbGiallo" -> orbGialliLivello.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                    case "fine" -> fine.add(new Img("/resources/images/" + campi[0], campi[1], Integer.parseInt(campi[2]), Integer.parseInt(campi[3]), Integer.parseInt(campi[4]), Integer.parseInt(campi[5]), Integer.parseInt(campi[6])));
                }
            }
            
            if(campi[0].equals("music")) titoloMusica = campi[1];
            
            if(campi[0].equals("perc")) migliorPercentuale = Float.parseFloat(campi[1]);
            
        }
        
    }
    
    int lunghezzaLivello = 0;
    
    private void calcolaLunghezzaTotale(List<String> righe) {
       
        for (String riga : righe) {
            String[] campi = riga.split(",");
            if(campi[1].equals("fine")) {
                lunghezzaLivello = Integer.parseInt(campi[4]);
                return;
            }
            
        }
    }
    
    
    public void spostaScena(String verso, float spostamentoCalcolato) {
        
        float spostamentox = 0, spostamentoy = 0;
        
        switch(verso) {
            case "destra" -> spostamentox = -100;
            case "sinistra" -> spostamentox = 100;
            case "sopra" -> {
                if(spostamentoCalcolato == -1) spostamentoy = 100; 
                else spostamentoy = spostamentoCalcolato * -1;
            }
            case "sotto" -> {
                if(spostamentoCalcolato == -1) spostamentoy = -100; 
                else spostamentoy = spostamentoCalcolato;
            }
        }
        
        offsetx -= spostamentox;
        offsety -= spostamentoy;
        
        if(offsetx < 0) {
            offsetx = 0;
            return;
        }
        if(offsety > 0) {
            offsety = 0;
            return;
        }
        
        List<ArrayList<Img>> Liste = Arrays.asList(
            spiniLivello, piattaformeLivello, portaliGravitaGialloLivello, 
            portaliGravitaBluLivello, portaliNavicellaLivello, portaliCuboLivello, 
            padGialliLivello, orbGialliLivello, backgroundTexture, groundTexture, fine
        );

        for (ArrayList<Img> lista : Liste) {
            for (Img img : lista) {
                img.setX(img.getX() + spostamentox);
                img.setY(img.getY() + spostamentoy);
            }
        }
        
    }
    
    public void ripristinaPosScena() {
        
        List<ArrayList<Img>> tutteLeListe = Arrays.asList(
            spiniLivello, piattaformeLivello, portaliGravitaGialloLivello, 
            portaliGravitaBluLivello, portaliNavicellaLivello, portaliCuboLivello, 
            padGialliLivello, orbGialliLivello, backgroundTexture, groundTexture, fine
        );

        for (ArrayList<Img> lista : tutteLeListe) {
            for (Img img : lista) {
                img.setX(img.getX() + offsetx);
                img.setY(img.getY() + offsety);
            }
        }
        
    }

public void createBackgroundTexture() {
    backgroundTexture.clear();
    int[] larghezze = {300, 400, 500};  
    int[] numTile   = {4, 6, 8, 10}; 
    int offset = 25;
    int currentX = 0;
    int limiteMappa = 100000; 
    Color color = LvColor.darker();
    Random rand = new Random();

    while (currentX < limiteMappa) {
        int rectW = larghezze[rand.nextInt(larghezze.length)]; 
        int nRettangoli = numTile[rand.nextInt(numTile.length)];
        int rectH = (5450 - (offset * (nRettangoli + 1))) / nRettangoli; 

        int currentY = offset;
        for (int i = 0; i < nRettangoli; i++) {
            backgroundTexture.add(new Img("textureSfondo", rectW, rectH, currentX, currentY - 4000, color, 0));
            currentY += rectH + offset;
        }
        currentX += rectW + offset;
    }
}
    
    

public void createGroundTexture() {
    groundTexture.clear();
    int limiteMappa = 100000; 
    int currentX = 0;
    Color color = LvColor.darker().darker();
    
    while(currentX < limiteMappa) {
        groundTexture.add(new Img("textureGround", 430, 500, currentX, 1150, color, 0));
        currentX += 430;
    }
}

public void createLVMenuEditor() {
    Color textColor = Color.WHITE;
    Color btnColor = Color.GREEN;
    menuLivelloEditor.add(new Img("/resources/images/sfondoMenuLivelliEditor.png", "sfondoMenuEditor", 1350, 1000, 605, 50, 0));
    menuLivelloEditor.add(new Img("/resources/images/barraMenuLivelliLateraleEditor.png", "barraMenuEditor", 70, 1079, 550, 50, 0));
    menuLivelloEditor.add(new Img("/resources/images/barraMenuLivelliLateraleEditor.png", "barraMenuEditor", 70, 1079, 1940, 50, 180));
    menuLivelloEditor.add(new Img("/resources/images/barraMenuLivelliInferioreEditor.png", "barraMenuEditor", 1500, 150, 530, 1050, 0));
    menuLivelloEditor.add(new Img("/resources/images/barraMenuLivelliEditor.png", "barraMenuEditor", 1500, 200, 530, 42, 0));
    
    int i;
    int offset = 250;
    
    
    for(i=0;i<livelliPersonalizzati.size();i++) {
        stringheLivelli.add(new Img("text", 1000, 200, 700, (250 + (i * offset)), textColor, 0));
        
        String riga = livelliPersonalizzati.get(i).get(0);
        riga = riga.toUpperCase(); riga = riga.substring(1);
        stringheLivelli.getLast().setContenuto(riga);
        livelliPersonalizzatiButtons.add(new Img("button", 200, 70, 1650, (300 + (i * offset)), btnColor, 0));
        livelliPersonalizzatiButtons.getLast().setId(Integer.toString(i));
        livelliPersonalizzatiButtons.getLast().setContenutoBottone("PLAY");

    }
    
    btnColor = new Color(200, 160, 255);
    
    livelliPersonalizzatiButtons.add(new Img("button", 150, 150, 2350, 1250, btnColor, 0));
    livelliPersonalizzatiButtons.getLast().setId(Integer.toString(i));
    livelliPersonalizzatiButtons.getLast().setContenutoBottone("NEW");
    
    
    
}


    // ============================================================
    //  GETTER — Accesso agli oggetti del livello
    // ============================================================

    /** @return Il colore di sfondo del livello. */
    public Color getLvColor() { return LvColor; }

    /** @return La lista delle spine del livello. */
    public ArrayList<Img> getSpini() { return spiniLivello; }

    /** @return La lista delle piattaforme del livello. */
    public ArrayList<Img> getPiattaforme() { return piattaformeLivello; }

    /** @return La lista dei portali gravità giallo (invertono la gravità). */
    public ArrayList<Img> getPortaliGravitaGiallo() { return portaliGravitaGialloLivello; }

    /** @return La lista dei portali gravità blu (ripristinano la gravità normale). */
    public ArrayList<Img> getPortaliGravitaBlu() { return portaliGravitaBluLivello; }

    /** @return La lista dei portali navicella. */
    public ArrayList<Img> getPortaliNavicella() { return portaliNavicellaLivello; }

    /** @return La lista dei portali cubo. */
    public ArrayList<Img> getPortaliCubo() { return portaliCuboLivello; }

    /** @return La lista dei pad di salto gialli. */
    public ArrayList<Img> getPadGialli() { return padGialliLivello; }

    /** @return La lista degli orb gialli. */
    public ArrayList<Img> getOrbGialli() { return orbGialliLivello; }

    /** @return L'oggetto marcatore di fine livello. */
    public ArrayList<Img> getFine() { return fine; }
    
    /** @return La texture dello sfondo. */
    public ArrayList<Img> getBackgroundTexture() { return backgroundTexture; }
    
    /** @return La texture del pavimento. */
    public ArrayList<Img> getGroundTexture() { return groundTexture; }
    
    /** @return La texture del pavimento. */
    public String getMusic() { return titoloMusica; }
    
    public int getLunghezzaLivello() { return lunghezzaLivello; }
    
    public Float getMigliorPercentuale() { return migliorPercentuale; }
    
    public int getOffsetY() { return offsety; }
    
    float min = 0;
    
    public float getPosizionePrimoOggetto() {
        List<ArrayList<Img>> tutteLeListe = Arrays.asList(
            spiniLivello, piattaformeLivello, portaliGravitaGialloLivello, 
            portaliGravitaBluLivello, portaliNavicellaLivello, portaliCuboLivello, 
            padGialliLivello, orbGialliLivello, backgroundTexture, groundTexture, fine
        );
        
        
        for(List<Img> lista : tutteLeListe) {
            for(Img e : lista) {
                if(e.getX() < min) min = e.getX();
            }
        }
                
        return min;
    }
    
    public void setOffsetY(int offsety) { this.offsety = offsety; }
    
    public void setMigliorPrecentuale(Float migliorPercentuale) { this.migliorPercentuale = migliorPercentuale; }
}