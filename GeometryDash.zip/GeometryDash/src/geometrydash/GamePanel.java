package geometrydash;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.DocumentEvent;

/**
 * GamePanel è il cuore visivo del gioco. Gestisce il rendering di tutti gli oggetti,
 * l'interfaccia utente (UI), i menu e il sistema di scaling dinamico per diverse risoluzioni.
 */
class GamePanel extends JPanel {

    // ============================================================
    //  OGGETTI DI GIOCO (Riferimenti alle entità grafiche)
    // ============================================================
    Img cubo, piattaforma, titolo, schermataVittoria;

    // Liste di oggetti presenti nel livello (ostacoli, interazioni, decorazioni)
    ArrayList<Img> spini, piattaforme, portaliGravitaGiallo, portaliGravitaBlu;
    ArrayList<Img> portaliNavicella, portaliCubo, padGialli, orbGialli;
    ArrayList<Img> backgroundTexture, groundTexture, fine;

    // Riferimenti ai controller esterni
    GeometryDash mainFrame;      // Il frame principale dell'applicazione
    EditorController editor;     // Gestisce la logica di creazione livelli
    MusicPlayer music;           // Gestisce la riproduzione audio

    // ============================================================
    //  FLAGS DI STATO (Controllano cosa sta succedendo nel gioco)
    // ============================================================
    boolean isGameStarted = false;      // Vero se il giocatore è in una sessione di gioco attiva
    boolean menuEdit = false;           // Vero se siamo nel menu di scelta livelli dell'editor
    boolean isGameWin = false;          // Vero se il livello è stato completato
    boolean cuboDeleted = false;        // Vero se il giocatore è esploso
    boolean cubeHided = false;          // Vero se il cubo deve essere nascosto (es. transizioni)
    boolean disattivaBackground = false; // Flag per ottimizzazione o effetti visivi

    // ============================================================
    //  SISTEMA DI SCALING (Permette al gioco di adattarsi a ogni monitor)
    // ============================================================
    private static final int BASE_W = 2560; // Larghezza di riferimento (progettazione originale)
    private static final int BASE_H = 1440; // Altezza di riferimento
    public double scale = 1.0;              // Fattore di scala calcolato a runtime
    
    String schermataCorrente; // Identifica il menu/stato attuale (es. "menuIniziale", "menuLivelli")

    // Informazioni sullo schermo fisico
    java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    int screenW = (int) screenSize.getWidth();
    int screenH = (int) screenSize.getHeight();
    int dimensioneIdeale = 375;      // Dimensione base bottoni menu principale
    int dimensioneBtnEditor = 100;   // Dimensione base bottoni strumenti editor

    // ============================================================
    //  BOTTONI E COMPONENTI UI
    // ============================================================
    private final JButton giocaBtn, editBtn, customizeBtn; // Bottoni principali del menu
    private final List<JButton> menuButtons;

    JButton tornaMenu = new JButton("TORNA AL MENU"); // Appare dopo la vittoria
    JButton[] lvlButtons = new JButton[3];            // Bottoni per i livelli ufficiali
    JTextField rinominaLivello;                       // Input testo per rinominare file editor
    
    // Liste per la gestione dinamica del menu editor personalizzato
    ArrayList<Img> menuLivelloEditor;
    ArrayList<Img> stringheLivelli;
    ArrayList<Img> livelliPersonalizzatiButtons;
    
    // Mappa per associare i tipi di oggetto dell'editor ai rispettivi bottoni grafici
    private final Map<String, JButton> editorButtons = new LinkedHashMap<>();

    private static final String[] EDITOR_TIPI = {
        "spina", "piattaforma", "orbGiallo", "padGiallo",
        "portaleCubo", "portaleNavicella", "portaleGravitaBlu", "portaleGravitaGiallo", "fine"
    };
    private static final String[] EDITOR_IMG = {
        "spina.png", "piattaforma.png", "orbGiallo.png", "padGiallo.png",
        "portaleCubo.png", "portaleNavicella.png", "portaleBlu.png", "portaleGiallo.png", "scrittafine.png"
    };

    // ============================================================
    //  COSTRUTTORE (Inizializzazione e Setup Eventi)
    // ============================================================
    public GamePanel(GeometryDash frame, Img cubo, Img piattaforma,
                     ArrayList<Img> spini,       ArrayList<Img> piattaforme,
                     ArrayList<Img> portaliGravitaGiallo, ArrayList<Img> portaliGravitaBlu,
                     ArrayList<Img> portaliNavicella,      ArrayList<Img> portaliCubo,
                     ArrayList<Img> fine,         ArrayList<Img> padGialli,  ArrayList<Img> orbGialli,
                     ArrayList<Img> backgroundTexture,     ArrayList<Img> groundTexture,
                     Img titolo, Img sfondo) {

        // Assegnazione riferimenti passati dal costruttore
        this.mainFrame = frame;
        this.cubo = cubo;
        this.piattaforma = piattaforma;
        this.spini = spini;
        this.piattaforme = piattaforme;
        this.portaliGravitaGiallo = portaliGravitaGiallo;
        this.portaliGravitaBlu = portaliGravitaBlu;
        this.portaliNavicella = portaliNavicella;
        this.portaliCubo = portaliCubo;
        this.padGialli = padGialli;
        this.orbGialli = orbGialli;
        this.backgroundTexture = backgroundTexture;
        this.groundTexture = groundTexture;
        this.fine = fine;
        this.titolo = titolo;
        
        this.schermataCorrente = "menuIniziale";

        setDoubleBuffered(true); // Abilita il doppio buffer per evitare sfarfallii (flickering)
        setLayout(null);         // Layout nullo per posizionamento manuale tramite coordinate virtuali

        // --- Inizializzazione Bottoni menu principale ---
        giocaBtn     = creaBottone("playButton.png",      dimensioneIdeale, false);
        editBtn      = creaBottone("editButton.png",      dimensioneIdeale, false);
        customizeBtn = creaBottone("customizeButton.png", dimensioneIdeale, false);
        rinominaLivello = creaCampoTesto("MIAO", (dimensioneIdeale - 20), true);
        menuButtons  = List.of(giocaBtn, editBtn, customizeBtn);

        // --- Inizializzazione Bottoni editor ---
        for (int i = 0; i < EDITOR_TIPI.length; i++) {
            JButton btn = creaBottone(EDITOR_IMG[i], dimensioneBtnEditor, false);
            btn.setVisible(false);
            editorButtons.put(EDITOR_TIPI[i], btn);
        }

        // --- Posizionamento iniziale differito ---
        // SwingUtilities.invokeLater assicura che il posizionamento avvenga quando i componenti sono pronti
        SwingUtilities.invokeLater(() -> {
            posizionaBottone(giocaBtn,      1025, 600, 500, 500);
            posizionaBottone(editBtn,       1700, 600, 500, 500);
            posizionaBottone(customizeBtn,   400, 600, 500, 500);
            posizionaCampoTesto(rinominaLivello, 50, 20, 600, 70);
            
            int i = 0;
            for (JButton btn : editorButtons.values()) {
                posizionaBottone(btn, i*200, screenH - 200, dimensioneBtnEditor + 150, dimensioneBtnEditor + 150);
                i++;
            }
        });

        // Aggiunta fisica dei componenti al pannello
        menuButtons.forEach(this::add);
        editorButtons.values().forEach(this::add);
        add(rinominaLivello);
        
        // --- Gestione Eventi (Action Listeners) ---
        giocaBtn.addActionListener(e -> {
            this.schermataCorrente = "menuLivelli";
            menuButtons.forEach(b -> b.setVisible(false));
            mostraMenuLivelli(); // Carica la lista dei livelli ufficiali
            repaint();
        });

        editBtn.addActionListener(e -> {
            this.schermataCorrente = "menuEditor";
            menuButtons.forEach(b -> b.setVisible(false));
            try { mostraMenuEdit(); } catch (IOException ex) { ex.printStackTrace(); }
            repaint();
        });

        customizeBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(mainFrame, "Coming Soon!", "Status", JOptionPane.INFORMATION_MESSAGE);
        });
        
        // Listener per il campo di testo: rinomina il livello in tempo reale mentre scrivi
        rinominaLivello.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(DocumentEvent e) { azione(); }
            public void removeUpdate(DocumentEvent e) { azione(); }
            public void insertUpdate(DocumentEvent e) { azione(); }

            private void azione() {
                String nuovoTesto = rinominaLivello.getText().trim();
                String riga = nuovoTesto.equals("") ? "# Livello" : "# " + nuovoTesto + "\n";
                mainFrame.rinominaLivello(riga); // Comunica al frame il nuovo nome
            }
        });
        
        rinominaLivello.setVisible(false);

        // Associa a ogni bottone dell'editor il tipo di blocco corrispondente
        editorButtons.forEach((tipo, btn) -> btn.addActionListener(e -> editor.setTipoSelezionato(tipo)));

        // --- Resize Listener: Gestisce il ricalcolo delle posizioni quando si ridimensiona la finestra ---
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                // Calcola il nuovo fattore di scala mantenendo le proporzioni
                scale = Math.min((double) getWidth() / BASE_W, (double) getHeight() / BASE_H);

                // Riposiziona i bottoni del menu principale
                posizionaBottone(giocaBtn,      1025, 600, 500, 500);
                posizionaBottone(editBtn,       1700, 600, 500, 500);
                posizionaBottone(customizeBtn,   400, 600, 500, 500);
                posizionaCampoTesto(rinominaLivello, 50, 20, 600, 70);

                // Riposiziona i bottoni di selezione livello
                for (int i = 0; i < lvlButtons.length; i++) {
                    if (lvlButtons[i] != null) {
                        int lBase = 400, hBase = 900;
                        int xBase = 530 + (lBase + 150) * i;
                        int yBase = 300;
                        posizionaBottone(lvlButtons[i], xBase, yBase, lBase, hBase);
                    }
                }

                // Riposiziona la barra degli strumenti dell'editor
                int i = 0;
                for (JButton btn : editorButtons.values()) {
                    posizionaBottone(btn, (i*200), BASE_H - 250, dimensioneBtnEditor + 150, dimensioneBtnEditor + 150);
                    i++;
                }
                repaint();
            }
        });
    }

    // ============================================================
    //  FACTORY METHODS (Creazione semplificata di componenti UI)
    // ============================================================

    // Crea un bottone con un'immagine scalata e stile trasparente
    private JButton creaBottone(String nomeFile, int size, boolean bordo) {
        String path = "./src/resources/images/" + nomeFile;
        Image img   = new ImageIcon(path).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH);
        JButton btn = new JButton(new ImageIcon(img));
        btn.setPreferredSize(new Dimension(size, size));
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(bordo);
        btn.setFocusPainted(false);
        btn.setRolloverEnabled(false);
        btn.setFocusable(false);
        return btn;
    }
    
    // Crea il campo di testo stilizzato per il nome del livello
    private JTextField creaCampoTesto(String testoIniziale, int size, boolean bordo) {
        JTextField txt = new JTextField(testoIniziale);
        txt.setPreferredSize(new Dimension(size * 4, size)); 
        txt.setFont(new Font("SansSerif", Font.BOLD, size));
        txt.setBackground(Color.BLUE);
        txt.setForeground(Color.WHITE); 
        txt.setCaretColor(Color.WHITE); 
        txt.setEditable(true);
        if (!bordo) txt.setBorder(BorderFactory.createEmptyBorder());
        txt.setHorizontalAlignment(JTextField.CENTER);
        return txt;
    }

    // ============================================================
    //  POSIZIONAMENTO IN COORDINATE VIRTUALI (2560x1440)
    // ============================================================
    // Queste funzioni permettono di posizionare elementi usando coordinate "fisse", 
    // che vengono poi tradotte in coordinate reali in base alla risoluzione attuale.

    private void posizionaBottone(JButton btn, int vx, int vy, int vw, int vh) {
        double s  = Math.min((double) getWidth() / BASE_W, (double) getHeight() / BASE_H);
        double ox = (getWidth()  - BASE_W * s) / 2.0; // Offset per centrare (letterboxing)
        double oy = (getHeight() - BASE_H * s) / 2.0;
        btn.setBounds((int)(ox + vx*s), (int)(oy + vy*s), (int)(vw*s), (int)(vh*s));
        btn.setFont(new Font("Arial", Font.BOLD, (int)(30 * s)));
    }
    
    private void posizionaCampoTesto(JTextField txt, int vx, int vy, int vw, int vh) {
        double s  = Math.min((double) getWidth() / BASE_W, (double) getHeight() / BASE_H);
        double ox = (getWidth()  - BASE_W * s) / 2.0;
        double oy = (getHeight() - BASE_H * s) / 2.0;
        txt.setBounds((int)(ox + vx * s), (int)(oy + vy * s), (int)(vw * s), (int)(vh * s));
        txt.setFont(txt.getFont().deriveFont((float)(50 * s)));
    }

    // ============================================================
    //  GESTIONE MENU EDITOR
    // ============================================================

    private void mostraMenuEdit() throws IOException {
        mainFrame.caricaMenuEditor(); // Carica la lista dei livelli creati dall'utente
        menuEdit = true;
        isGameStarted = true;
        revalidate();
        repaint();
    }
    
    public void selezionaLivelloEditor(String id) throws IOException {
        editorButtons.values().forEach(b -> b.setVisible(true)); // Mostra tool dell'editor
        mainFrame.caricaAmbienteEditor(id); // Carica la mappa specifica
    }
    
    // Crea un nuovo file CSV per un livello personalizzato
    public void creaLivelloPersonalizzato() throws IOException {
        String cartellaEseguibile = System.getProperty("user.dir");
        Path PATH = Paths.get(cartellaEseguibile, "livelliPersonalizzati.csv");
        String[] righe = {"# Livello\n", "music,StereoMadness"};
        for(String r : righe) {
            Files.write(PATH, r.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        }
        mainFrame.caricaMenuEditor();
        revalidate(); repaint();
    }

    // ============================================================
    //  MENU SELEZIONE LIVELLI (Ufficiali)
    // ============================================================

    private void mostraMenuLivelli() {
        String[] nomiLivelli = {"TUTORIAL", "STEREO MADNESS", "DRY OUT"};
        int larghezzaBottone = 400, altezzaBottone = 900, spazioTraBottoni = 150;
        int xIniziale = 530, yIniziale = 300;

        final Image imgSfondo = new ImageIcon(getClass().getResource("/resources/images/levelBtn.png")).getImage();

        for (int i = 0; i < 3; i++) {
            final int num = i + 1;
            final String nome = nomiLivelli[i];
            
            // Calcolo e recupero della miglior percentuale di completamento salvata
            String percTemp = "0%";
            try {
                Livello livelloTemp = new Livello(num, this, null);
                Float perc = livelloTemp.getMigliorPercentuale();
                percTemp = (perc != null) ? String.format("%.2f%%", perc) : "0%";
            } catch (IOException ex) { ex.printStackTrace(); }
            final String testoPerc = percTemp;

            // CREIAMO UN BOTTONE CUSTOM: Sovrascriviamo paintComponent per disegnare 
            // l'interfaccia del livello (sfondo bottone, nome e percentuale) dinamicamente.
            lvlButtons[i] = new JButton() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    // Antialiasing per testi e grafica più puliti
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                    int w = getWidth(), h = getHeight();
                    if (w == 0 || h == 0) return;

                    // 1. Disegna l'immagine di sfondo del bottone
                    g2d.drawImage(imgSfondo, 0, 0, w, h, this);

                    // 2. Calcola scala locale basata sull'altezza attuale del bottone
                    double localScale = (double) h / 900.0;

                    // 3. Disegna il Nome del Livello
                    g2d.setColor(Color.WHITE);
                    g2d.setFont(new Font("Arial", Font.BOLD, Math.max(10, (int)(35 * localScale))));
                    FontMetrics fmNome = g2d.getFontMetrics();
                    int nomeX = (w - fmNome.stringWidth(nome)) / 2;
                    int nomeY = (int)(350 * localScale) + fmNome.getAscent();
                    g2d.drawString(nome, nomeX, nomeY);

                    // 4. Disegna la Percentuale
                    g2d.setFont(new Font("Arial", Font.BOLD, Math.max(10, (int)(48 * localScale))));
                    FontMetrics fmPerc = g2d.getFontMetrics();
                    int percX = (w - fmPerc.stringWidth(testoPerc)) / 2;
                    int percY = (int)(820 * localScale) + fmPerc.getAscent();
                    g2d.drawString(testoPerc, percX, percY);

                    g2d.dispose();
                }
            };

            // Setup estetico del bottone (trasparente, senza bordi standard)
            lvlButtons[i].setBorderPainted(false);
            lvlButtons[i].setFocusPainted(false);
            lvlButtons[i].setContentAreaFilled(false);

            // Azione del click: Avvia il livello selezionato
            lvlButtons[i].addActionListener(e -> {
                music.ferma();
                this.schermataCorrente = "livelloInCorso";
                cubeHided = false;
                cubo.setX(-200); // Resetta posizione cubo
                mainFrame.setCuboCentrato(false);
                try { selezionaLivello(num); } catch (IOException ex) { ex.printStackTrace(); }
            });

            add(lvlButtons[i]);
            int posX = xIniziale + (larghezzaBottone + spazioTraBottoni) * i;
            posizionaBottone(lvlButtons[i], posX, yIniziale, larghezzaBottone, altezzaBottone);
        }
        revalidate(); repaint();
    }
    
    // Gestisce la navigazione a ritroso tra i menu (Tasto Esc o Indietro)
    public void tornaIndietro() throws IOException {
        switch(schermataCorrente) {
            case "menuIniziale" -> System.exit(0); // Esce dal programma
            case "menuLivelli" -> {
                for(JButton b : lvlButtons) { if(b != null) b.setVisible(false); }
                menuButtons.forEach(b -> b.setVisible(true));
                schermataCorrente = "menuIniziale";
            }
            case "livelloInCorso" -> {
                isGameStarted = false; 
                music.ferma();
                mainFrame.esciLivello();
                mainFrame.setCuboCentrato(true);
                mainFrame.creaAmbienteMenu();
                schermataCorrente = "menuLivelli";
                mostraMenuLivelli();
            }
            case "livelloInCorsoEditor" -> {
                isGameStarted = true;
                editorButtons.values().forEach(b -> b.setVisible(false));
                rinominaLivello.setVisible(false);
                mainFrame.esciLivello();
                music.ferma();
                mostraMenuEdit();
                mainFrame.isEditing = true;
                schermataCorrente = "menuEditor";
            }
            case "menuEditor" -> {
                menuEdit = false; isGameStarted = false;
                editorButtons.values().forEach(b -> b.setVisible(false));
                menuButtons.forEach(b -> b.setVisible(true));
                rinominaLivello.setVisible(false);
                mainFrame.esciLivello();    
                mainFrame.setCuboCentrato(true);
                mainFrame.creaAmbienteMenu();
                mainFrame.isEditing = false;
                schermataCorrente = "menuIniziale";
            }
            case "menuCustomize" -> {
                menuButtons.forEach(b -> b.setVisible(true));            
                schermataCorrente = "menuIniziale";
            }
        }
        this.revalidate(); this.repaint();
    }

    // ============================================================
    //  SCHERMATA VITTORIA
    // ============================================================

    public void creaMenuVittoria() {
        // Carica l'immagine "Level Complete"
        schermataVittoria = new Img("/resources/images/end_level.png", "schermataVittoria", 1150, 900, 500, 300, 0);

        // Configura il bottone per tornare al menu
        tornaMenu.setFont(new Font("Arial", Font.BOLD, 30));
        tornaMenu.setBackground(Color.WHITE);
        tornaMenu.setForeground(Color.BLACK);
        tornaMenu.setFocusPainted(false);
        tornaMenu.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
        posizionaBottone(tornaMenu, 1130, 800, 400, 100);
        tornaMenu.setVisible(true);
        
        tornaMenu.addActionListener(e -> {
            schermataCorrente = "menuIniziale";
            music.ferma();
            music.avvia("/resources/music/menuLoop.wav");
            isGameStarted = false;
            try {
                mainFrame.esciLivello();
                mainFrame.creaAmbienteMenu();
            } catch (IOException ex) { ex.printStackTrace(); }
            mainFrame.setCuboCentrato(true);
            tornaMenu.setVisible(false);
            menuButtons.forEach(b -> b.setVisible(true));
            editorButtons.values().forEach(b -> b.setVisible(false));
            rinominaLivello.setVisible(false);
            schermataVittoria = null;
            for (JButton b : lvlButtons) { if (b != null) add(b); }
        });

        add(tornaMenu);
        revalidate();
    }

    // Avvia la logica di caricamento di un livello specifico
    private void selezionaLivello(int n) throws IOException {
        for (JButton b : lvlButtons) { if (b != null) b.setVisible(false); }
        mainFrame.caricaLivelloSpecifico(n);
        isGameStarted = true;
        revalidate(); repaint();
        // Sposta il focus sul pannello per ricevere input da tastiera
        Window parent = SwingUtilities.getWindowAncestor(this);
        if (parent != null) parent.requestFocusInWindow();
    }

    // ============================================================
    //  RENDERING (Il ciclo di disegno)
    // ============================================================

    private static final AffineTransform IDENTITY = new AffineTransform();

    @Override
    protected void paintChildren(Graphics g) {
        // Assicura che i bottoni Swing siano disegnati con la trasformazione corretta
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setTransform(IDENTITY); 
        super.paintChildren(g2d);
        g2d.dispose();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getWidth() <= 0 || getHeight() <= 0) return;

        Graphics2D g2d = (Graphics2D) g;
        // Ricalcola scala e offset per mantenere l'aspect ratio (letterbox)
        scale = Math.min((double) getWidth() / BASE_W, (double) getHeight() / BASE_H);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        double ox = (getWidth()  - BASE_W * scale) / 2.0;
        double oy = (getHeight() - BASE_H * scale) / 2.0;
        
        // Applica trasformazione globale per disegnare tutto in "coordinate virtuali"
        g2d.translate(ox, oy);
        g2d.scale(scale, scale);
        
        // --- Disegno Sfondi e Terreno ---
        if(!disattivaBackground) disegnaConColore(g2d, backgroundTexture);
        disegna(g2d, groundTexture);

        // Disegna la linea della piattaforma principale
        g2d.drawImage(piattaforma.getBufferedImage(),
            (int) piattaforma.getX(), (int) piattaforma.getY(), BASE_W, piattaforma.getH(), null);

        // --- Disegno Ostacoli e Oggetti ---
        disegnaConRotazione(g2d, spini);
        disegna(g2d, piattaforme);
        disegna(g2d, portaliGravitaGiallo);
        disegna(g2d, portaliGravitaBlu);
        disegna(g2d, portaliNavicella);
        disegna(g2d, portaliCubo);
        disegna(g2d, padGialli);
        disegna(g2d, orbGialli);
        
        // Elementi specifici del menu editor
        if(menuEdit) {
            disegnaConRotazione(g2d, menuLivelloEditor);
            disegnaConRotazione(g2d, stringheLivelli);
            disegna(g2d, livelliPersonalizzatiButtons);
        }

        // --- Disegno del Cubo (con rotazione propria) ---
        if (!cubeHided && !cuboDeleted) {
            AffineTransform old = g2d.getTransform();
            // Sposta l'origine al centro del cubo per ruotarlo correttamente
            g2d.translate(cubo.getX() + cubo.getW() / 2.0, cubo.getY() + cubo.getH() / 2.0);
            g2d.rotate(Math.toRadians(cubo.getRotation()));
            g2d.drawImage(cubo.getBufferedImage(), -cubo.getW() / 2, -cubo.getH() / 2, cubo.getW(), cubo.getH(), null);
            g2d.setTransform(old); // Ripristina trasformazione
        } 
        
        // Disegna logo titolo solo nel menu
        if(schermataCorrente.equals("menuIniziale") && titolo != null) {
            g2d.drawImage(titolo.getBufferedImage(), (BASE_W - titolo.getW()) / 2, 200, titolo.getW(), titolo.getH(), null);
        }

        // Disegna overlay vittoria
        if (isGameWin)
            g2d.drawImage(schermataVittoria.getBufferedImage(), 650, 300, 1300, 800, null);

        // Sincronizzazione grafica per Linux/alcuni sistemi video
        java.awt.Toolkit.getDefaultToolkit().sync();
    }

    // Metodi helper per iterare e disegnare liste di immagini
    private void disegna(Graphics2D g2d, ArrayList<Img> lista) {
        for (Img img : lista) {
            // Culling (Ottimizzazione)
            if (img.getX() > BASE_W || img.getX() < -img.getW()) continue;

            AffineTransform at = g2d.getTransform(); // Salva
            g2d.translate(img.getX(), img.getY());   // Usa i FLOAT/DOUBLE
            g2d.drawImage(img.getBufferedImage(), 0, 0, img.getW(), img.getH(), null);
            g2d.setTransform(at); // Ripristina
        }
    }
    
    private void disegnaConColore(Graphics2D g2d, ArrayList<Img> lista) {
        for (Img img : lista) {
            if (img.getX() > BASE_W && img.getX() > -200) continue;
            
            AffineTransform at = g2d.getTransform(); // Salva
            g2d.translate(img.getX(), img.getY());   // Usa i FLOAT/DOUBLE
            g2d.drawImage(img.getBufferedImage(), 0, 0, img.getW(), img.getH(), null);
            g2d.setTransform(at);
        }
    }

    private void disegnaConRotazione(Graphics2D g2d, ArrayList<Img> lista) {
        for (Img img : lista) {
            if (img.getX() > BASE_W || img.getX() < -img.getW()) continue;

            AffineTransform at = g2d.getTransform();
            // Sposta nel punto decimale esatto
            g2d.translate(img.getX() + img.getW() / 2.0, img.getY() + img.getH() / 2.0);
            g2d.rotate(Math.toRadians(img.getRotation()));
            // Disegna centrato
            g2d.drawImage(img.getBufferedImage(), -img.getW() / 2, -img.getH() / 2, img.getW(), img.getH(), null);
            g2d.setTransform(at);
        }
    } 
    
    // Gestisce il click del mouse per selezionare i livelli creati dall'utente nel menu Editor
    public void controllaBottoniMenuEdit(MouseEvent e) throws IOException {
        double s  = Math.min((double) getWidth() / BASE_W, (double) getHeight() / BASE_H);
        double ox = (getWidth()  - BASE_W * s) / 2.0;
        double oy = (getHeight() - BASE_H * s) / 2.0;

        // Trasforma coordinate mouse (pixel reali) → coordinate virtuali gioco
        double mx = (e.getX() - ox) / s;
        double my = (e.getY() - oy) / s;

        for (Img img : livelliPersonalizzatiButtons) {
            // Controllo collisione punto (mouse) - rettangolo (bottone)
            if (mx >= img.getX() && mx <= img.getX() + img.getW() &&
                my >= img.getY() && my <= img.getY() + img.getH()) {
                
                if(img.getContenuto().equals("NEW")) {
                    creaLivelloPersonalizzato();
                } else {
                    rinominaLivello.setVisible(true);
                    isGameStarted = false;
                    cubeHided = false;
                    cubo.setX(-200);
                    cubo.setY(1000);
                    mainFrame.setCuboCentrato(false);
                    mainFrame.fermaGioco();
                    selezionaLivelloEditor(img.getId());
                    rinominaLivello.setText(mainFrame.getNomeLivello().toUpperCase());
                }
                break;
            }
        }
    }

    // ============================================================
    //  GETTERS / SETTERS / UTILITÀ PUBBLICHE
    // ============================================================

    public Img  getCubo()                                         { return cubo;          }
    public int  getBaseH()                                        { return BASE_H;        }
    public int  getBaseW()                                        { return BASE_W;        }
    public void setEditor(EditorController e)                     { this.editor = e;      }
    public void setMusic(MusicPlayer m)                           { this.music = m;       }
    
    public void setLvMenuEditor(ArrayList<Img> menuLivelloEditor) {
        this.menuLivelloEditor = menuLivelloEditor; 
        try {
            System.out.println(menuLivelloEditor.getFirst() == null);
        } catch(NoSuchElementException e) {
            menuEdit = false;
            mainFrame.isEditing = true;
            isGameStarted = true;
            revalidate(); repaint();
        }
    }
    
    public void setStringheLivelli(ArrayList<Img> stringheLivelli) { this.stringheLivelli = stringheLivelli; }
    public void setLivelliPersonalizzatiButtons(ArrayList<Img> livelliPersonalizzatiButtons) { this.livelliPersonalizzatiButtons = livelliPersonalizzatiButtons; }
    
    public void setIsGameStarted(boolean v) { 
        isGameStarted = v;    
        schermataCorrente = "livelloInCorsoEditor";
    }
    
    // Gestisce la "morte" del cubo
    public void deleteCubo() { 
        cuboDeleted = true;
        music.riproduciEffetto("/resources/music/explode.wav");
        music.ferma();
        // Se non siamo nell'editor, aggiorna il record di percentuale se superato
        if(!schermataCorrente.equals("livelloInCorsoEditor")) {
            if (mainFrame.getPecentuale() > mainFrame.getMigliorPercentuale()){
                mainFrame.setMigliorPrecentuale(mainFrame.getPecentuale());
            }
        }
    }
}