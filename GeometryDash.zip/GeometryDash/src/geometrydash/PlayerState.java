package geometrydash;

public class PlayerState {
    public float[]   cont      = {0};
    public float[] contJump  = {0};
    public int     gravity   = 1;
    public float   speed     = 0;
    public boolean isJumping       = false;
    public boolean isGrounded      = false;
    public boolean isTouchingOrb   = false;
    public boolean suspendPhysics  = false;
    public boolean cuboCentrato    = false;
    public boolean gravityIsChanged = true;
    public boolean jumpPotenziato = false;
}