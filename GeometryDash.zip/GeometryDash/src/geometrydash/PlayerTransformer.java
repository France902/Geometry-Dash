package geometrydash;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

/**
 * PlayerTransformer è responsabile del cambio di stato grafico del giocatore.
 * Gestisce lo swapping delle texture tra le diverse modalità di gioco 
 * (Cubo, Navicella, ecc.) e aggiorna i metadati dell'oggetto Img.
 */
public class PlayerTransformer {

    private final GamePanel   gamePanel;
    private final ClassLoader loader;

    public PlayerTransformer(GamePanel gamePanel, ClassLoader loader) {
        this.gamePanel = gamePanel;
        this.loader    = loader;
    }

    /**
     * Trasforma il giocatore nella modalità Navicella (Ship).
     * Cambia la texture in quella del razzo e imposta il tipo per attivare la fisica del volo.
     */
    public void trasformaNavicella(Img cubo) {
        caricaImmagine(cubo, "/resources/images/razzo.png", "navicella");
    }

    /**
     * Ripristina il giocatore nella modalità Cubo standard.
     * Viene chiamata solitamente all'uscita dai portali o dopo un respawn.
     */
    public void trasformaCubo(Img cubo) {
        caricaImmagine(cubo, "/resources/images/cubo.png", "cubo");
    }

    /**
     * Metodo helper privato per il caricamento dinamico delle risorse.
     * Gestisce la risoluzione dei percorsi del file system e l'aggiornamento del buffer grafico.
     * * @param target L'oggetto Img del giocatore da modificare.
     * @param path   Il percorso relativo della nuova immagine.
     * @param tipo   La stringa identificativa del tipo (usata dal PhysicsEngine).
     */
    private void caricaImmagine(Img target, String path, String tipo) {
        // Cambia il tipo prima del caricamento per preparare il motore fisico
        target.setTipo(tipo);
        try {
            // Tenta il caricamento tramite il ClassLoader fornito (gestione JAR/IDE)
            URL resource = loader.getResource(path.startsWith("/") ? path.substring(1) : path);
            
            // Fallback sul caricamento classico se il loader primario fallisce
            if (resource == null) resource = getClass().getResource(path);
            
            if (resource != null) {
                BufferedImage img = javax.imageio.ImageIO.read(resource);
                target.setBufferedImage(img); // Aggiorna il buffer dell'immagine dell'oggetto
                
                // Richiede il ridisegno immediato del pannello di gioco per riflettere il cambio
                gamePanel.repaint();
            } else {
                throw new IOException("Risorsa non trovata: " + path);
            }
        } catch (IOException e) {
            System.out.println("Errore caricamento " + tipo + ": " + e.getMessage());
        }
    }
}