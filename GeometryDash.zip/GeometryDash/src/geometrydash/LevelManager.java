package geometrydash;

import java.awt.Color;
import javax.swing.Timer;
import java.io.IOException;
import java.util.ArrayList;

/**
 * LevelManager gestisce il ciclo di vita dei livelli (caricamento, reset, salvataggio).
 * Funge da ponte tra i dati grezzi della classe Livello e la visualizzazione nel GamePanel.
 */
public class LevelManager {

    private final ArrayList<Livello> livelli; // Lista contenente il livello corrente (solitamente un solo elemento)
    private       GamePanel       gamePanel;  // Riferimento alla superficie di disegno
    private final MusicPlayer       music;      // Gestore dell'audio
    private String id;                        // Identificatore univoco del livello (usato per file custom)
    private int livelloSelezionato;           // Indice del livello corrente (-1/-2 per editor, >=0 per ufficiali)

    public LevelManager(ArrayList<Livello> livelli, MusicPlayer music) {
        this.livelli   = livelli;
        this.music = music;
    }

    public int getLivelloSelezionato() { return livelloSelezionato; }
    
    /**
     * Salva permanentemente la percentuale di completamento raggiunta nel livello corrente.
     */
    public void ScriviLivelloUfficiale() {
        livelli.get(0).salvaMigliorPercentuale(livelloSelezionato);
    }

    /**
     * Carica un livello ufficiale specifico.
     * @param n Indice del livello.
     */
    public void caricaLivelloSpecifico(int n) throws IOException {
        Img.svuotaCache(); // Libera memoria dalle immagini precedenti
        id = "Nessun id";
        livelli.clear();
        livelli.add(new Livello(n, gamePanel, id));
        System.out.println(livelli.size());
        livelloSelezionato = n;
        sincronizzaGamePanel();
        gamePanel.isGameWin = false;
    }

    /**
     * Prepara l'ambiente per il menu di selezione dell'Editor.
     */
    public void caricaMenuEditor() throws IOException {
        id = "Nessun id";
        try {
            livelli.get(0).stopTimer(); // Ferma eventuali animazioni/logiche residue
        } catch(java.lang.NullPointerException e) { }
        
        livelli.clear();
        livelli.add(new Livello(-1, gamePanel, id)); // Convenzione -1: Menu Editor
        livelloSelezionato = -1;
        sincronizzaGamePanel();
        gamePanel.isGameWin = false;
    }
    
    /**
     * Carica lo spazio di lavoro dell'Editor per un livello personalizzato specifico.
     */
    public void caricaAmbienteEditor(String id) throws IOException {
        this.id = id;
        livelli.clear();
        livelli.add(new Livello(-2, gamePanel, id)); // Convenzione -2: Spazio di lavoro Editor
        livelloSelezionato = -2;
        sincronizzaGamePanel();
        gamePanel.isGameWin = false;
    }
    
    /**
     * Rimuove il livello corrente e pulisce i dati visivi.
     */
    public void esciLivello() throws IOException {
        livelli.set(0, null);
        sincronizzaGamePanel();
    }

    /**
     * Resetta il livello corrente (chiamato dopo una morte o restart manuale).
     */
    public void ricominciaLivello() throws IOException {
        Img.svuotaCache();
        livelli.clear();
        livelli.add(new Livello(livelloSelezionato, gamePanel, id));
        sincronizzaGamePanel();
        eseguiMusica();
        gamePanel.revalidate();
        gamePanel.repaint();
    }
    
    public String getNomeLivello() {
        return livelli.get(0).getNomeLivello(id);
    }
    
    public Float getMigliorPercentuale() { return livelli.get(0).getMigliorPercentuale(); }
    
    public void setMigliorPrecentuale(Float migliorPercentuale) { 
        livelli.get(0).setMigliorPrecentuale(migliorPercentuale); 
    }
    
    public void rinominaLivello(String riga) {
        livelli.get(0).rinominaLivello(riga, id);
    }

    /**
     * Passa tutti i dati degli oggetti (ostacoli, portali, piattaforme) dal modello (Livello) 
     * alla vista (GamePanel) affinché possano essere renderizzati.
     */
    private void sincronizzaGamePanel() {
        Livello lv = livelli.get(0);
        if(lv == null) {
            svuotaGamePanel();
        } else {
            gamePanel.setBackground(lv.getLvColor());
            gamePanel.spini               = lv.getSpini();
            gamePanel.piattaforme         = lv.getPiattaforme();
            gamePanel.portaliGravitaGiallo = lv.getPortaliGravitaGiallo();
            gamePanel.portaliGravitaBlu   = lv.getPortaliGravitaBlu();
            gamePanel.portaliNavicella    = lv.getPortaliNavicella();
            gamePanel.portaliCubo         = lv.getPortaliCubo();
            gamePanel.padGialli           = lv.getPadGialli();
            gamePanel.orbGialli           = lv.getOrbGialli();
            gamePanel.backgroundTexture   = lv.getBackgroundTexture();
            gamePanel.groundTexture       = lv.getGroundTexture();
            gamePanel.fine                = lv.getFine();
        }
    }
    
    /**
     * Pulisce tutte le liste di oggetti nel GamePanel per evitare residui grafici.
     */
    private void svuotaGamePanel() {
        gamePanel.spini.clear();
        gamePanel.piattaforme.clear();
        gamePanel.portaliGravitaGiallo.clear();
        gamePanel.portaliGravitaBlu.clear();
        gamePanel.portaliNavicella.clear();
        gamePanel.portaliCubo.clear();
        gamePanel.padGialli.clear();
        gamePanel.orbGialli.clear();
        gamePanel.backgroundTexture.clear();
        gamePanel.groundTexture.clear();
        gamePanel.fine.clear();
    }
    
    /**
     * Recupera il file audio associato al livello e avvia la riproduzione.
     */
    public void eseguiMusica() {
        String titolo = livelli.get(0).getMusic();
        String url = "/resources/music/"+ titolo + ".wav";
        music.avvia(url);
    }
    
    public void setGamePanel(GamePanel gp) {
        this.gamePanel = gp;
    }
}