package geometrydash;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.font.GlyphVector;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;      
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 * La classe Img gestisce la rappresentazione visiva di ogni oggetto nel gioco.
 * Supporta sia il caricamento di texture esterne che la generazione procedurale
 * di forme geometriche e testo con accelerazione hardware.
 */
public class Img {

    private BufferedImage bufferedImage;
    private int W, H;
    private float X, Y;
    private float rotation = 0;
    private String tipo;
    private Color color;
    private String url;
    private boolean isValid = true;
    
    private String id;
    private String contenuto;
    
    /**
     * CACHE DELLE FORME: Memorizza le versioni renderizzate di sfondi e terreni.
     * Evita di ricalcolare pixel per pixel oggetti identici (es. blocchi del suolo).
     */
    private static final Map<String, BufferedImage> cacheForme = new HashMap<>();
    
    int xText, yText;

    // ============================================================
    //  COSTRUTTORE PER IMMAGINI (Spine, Cubo, Portali)
    // ============================================================
    public Img(String url, String tipo, int W, int H, int X, int Y, float rotation) {
        this.url = url;
        this.W = W;
        this.H = H;
        this.X = X;
        this.Y = Y;
        this.tipo = tipo;
        this.rotation = rotation;

        // Recupera l'immagine scalata dal TextureManager (gestione centralizzata asset)
        this.bufferedImage = TextureManager.getTexture(url, W, H);
    }

    // ============================================================
    //  COSTRUTTORE PER FORME PROCEDURALI (Sfondi, Testo, Bottoni)
    // ============================================================
    public Img(String tipo, int W, int H, int X, int Y, Color color, float rotation) {
        this.W = W;
        this.H = H;
        this.X = X;
        this.Y = Y;
        this.tipo = tipo;
        this.color = color;
        this.rotation = rotation;

        // Genera una chiave univoca per la cache basata sulle proprietà della forma
        String key = tipo + "_" + W + "_" + H + "_" + (color != null ? color.getRGB() : "nocolor");
        
        // Verifica se la forma è già presente in cache (escluso testo e bottoni che sono dinamici)
        if (cacheForme.containsKey(key) && (!"text".equals(tipo) && !"button".equals(tipo))) {
            this.bufferedImage = cacheForme.get(key);
        } else {
            // Crea una BufferedImage compatibile con le impostazioni dello schermo corrente (Ottimizzazione VRAM)
            java.awt.GraphicsConfiguration config = java.awt.GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getDefaultScreenDevice()
                .getDefaultConfiguration();
            
            this.bufferedImage = config.createCompatibleImage(W, H, java.awt.Transparency.TRANSLUCENT);
            Graphics2D g2d = this.bufferedImage.createGraphics();
            
            // Attiva l'antialiasing per bordi morbidi
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Logica di disegno specifica per il tipo di elemento
            switch (tipo) {
                case "text" -> {
                    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    Font font = new Font("SansSerif", Font.BOLD, 70); 
                    g2d.setFont(font);
                    g2d.setColor(Color.WHITE);       
                    contenuto = "";
                    FontMetrics metrics = g2d.getFontMetrics(font);
                    xText = 0;
                    yText = ((H - metrics.getHeight()) / 2) + metrics.getAscent();
                    g2d.drawString(contenuto, xText, yText);
                }
                case "button" -> {
                    // Utilizza un componente Swing temporaneo per renderizzare lo stile del bottone sulla BufferedImage
                    JButton tempBtn = new JButton();
                    tempBtn.setSize(W, H);
                    tempBtn.setFont(new Font("Arial", Font.BOLD, 40));
                    tempBtn.setForeground(Color.WHITE);
                    tempBtn.setOpaque(false);
                    tempBtn.setContentAreaFilled(false);
                    tempBtn.setBorderPainted(false);
                    tempBtn.printAll(g2d);
                }
                case "textureSfondo" -> {
                    g2d.setColor(color); 
                    g2d.fillRect(0, 0, W, H); 
                    g2d.setColor(new Color(28, 28, 28)); // Colore dei bordi della griglia
                    g2d.setStroke(new BasicStroke(6));
                    g2d.drawLine(W - 1, 0, W - 1, H - 1);
                    g2d.drawLine(0, H - 2, W - 1, H - 2);
                }
                case "textureGround" -> {
                    g2d.setColor(color); 
                    g2d.fillRect(0, 0, W, H); 
                    g2d.setColor(color.brighter());
                    g2d.setStroke(new BasicStroke(25));
                    g2d.drawRect(0, 0, W - 1, H - 1);
                    g2d.setColor(new Color(28, 28, 28));
                    g2d.setStroke(new BasicStroke(3));
                    g2d.drawLine(W - 10, 14, W - 10, H - 1);
                    g2d.setColor(Color.WHITE);
                    g2d.setStroke(new BasicStroke(7)); // Linea superiore luminosa tipica di GD
                    g2d.drawLine(0, 0, W, 0);
                }
            }

            g2d.dispose();
            
            // Memorizza la forma generata per riutilizzi futuri
            cacheForme.put(key, this.bufferedImage);
        }
    }

    // --- GETTERS & SETTERS ---
    public BufferedImage getBufferedImage() { return bufferedImage; }
    public float getX() { return X; }
    public float getY() { return Y; }
    public void setX(float x) { this.X = x; }
    public void setY(float y) { this.Y = y; }
    public int getW() { return W; }
    public int getH() { return H; }
    public float getRotation() { return rotation; }
    public void setRotation(float r) { this.rotation = r; }
    public String getTipo() { return tipo; }
    public String getId() { return id; }
    public String getContenuto() { return contenuto; }
    
    /** Restituisce solo il nome del file dall'URL */
    public String getUrl(boolean normalised) { 
        String[] tempUrl = url.split("/");
        return tempUrl[tempUrl.length - 1]; 
    }
    
    public Color getColor() { return color; }
    public boolean getIsValid() { return isValid; }
    public void setIsValid(boolean isValid) { this.isValid = isValid; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public void setId(String id) { this.id = id; }
    public void setBufferedImage(BufferedImage img) { this.bufferedImage = img; }
    
    public void setContenuto(String contenuto) {
        this.contenuto = contenuto;
        ridisegna(); // Forza l'aggiornamento grafico del testo
    }
    
    public void setContenutoBottone(String contenuto) {
        this.contenuto = contenuto;
        ridisegna();
    }
    
    public void setColor(Color nuovoColor) {
        this.color = nuovoColor;
        ridisegna(); 
    }
    
    /**
     * Rilascia immediatamente le risorse della memoria video.
     * Fondamentale per evitare Memory Leak durante i cambi di livello.
     */
    public void dispose() {
        if (this.bufferedImage != null) {
            this.bufferedImage.flush();
            this.bufferedImage = null;
        }
        this.isValid = false;
    }
    
    /** Pulisce la cache globale delle forme */
    public static void svuotaCache() {
        for (BufferedImage img : cacheForme.values()) {
            if (img != null) img.flush();
        }
        cacheForme.clear();
    }

    /**
     * Metodo core per il rendering dinamico.
     * Viene chiamato quando proprietà come colore o testo cambiano.
     */
    private void ridisegna() {
        if (this.bufferedImage == null) return;

        Graphics2D g2d = this.bufferedImage.createGraphics();

        // Svuota l'area di disegno precedente (AlphaComposite.Clear)
        g2d.setComposite(AlphaComposite.Clear);
        g2d.fillRect(0, 0, W, H);
        g2d.setComposite(AlphaComposite.SrcOver);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        switch (this.tipo) {
            case "textureSfondo" -> {
                g2d.setColor(this.color); 
                g2d.fillRect(0, 0, W, H); 
                g2d.setColor(new Color(28, 28, 28));
                g2d.setStroke(new BasicStroke(6));
                g2d.drawLine(W - 1, 0, W - 1, H - 1);
                g2d.drawLine(0, H - 2, W - 1, H - 2);
            }
            case "textureGround" -> {
                g2d.setColor(this.color); 
                g2d.fillRect(0, 0, W, H); 
                g2d.setColor(this.color.brighter());
                g2d.setStroke(new BasicStroke(25));
                g2d.drawRect(0, 0, W - 1, H - 1);
                g2d.setColor(new Color(28, 28, 28));
                g2d.setStroke(new BasicStroke(3));
                g2d.drawLine(W - 10, 14, W - 10, H - 1);
                g2d.setColor(Color.WHITE);
                g2d.setStroke(new BasicStroke(7));
                g2d.drawLine(0, 0, W, 0);
            }
            
            case "text" -> {
                Font font = new Font("SansSerif", Font.BOLD, 70); 
                g2d.setFont(font);
                FontMetrics metrics = g2d.getFontMetrics(font);

                int xText = 0;
                int yText = ((H - metrics.getHeight()) / 2) + metrics.getAscent();

                // Genera il contorno del testo (Outline) tramite GlyphVector
                // Questo permette l'effetto "Testo bianco con bordo nero" tipico di GD
                GlyphVector gv = font.createGlyphVector(g2d.getFontRenderContext(), contenuto);
                Shape testoShape = gv.getOutline(xText, yText);

                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(5)); 
                g2d.draw(testoShape); // Disegna il bordo

                g2d.setColor(Color.WHITE); 
                g2d.fill(testoShape); // Riempie il corpo del testo
            }
            
            case "button" -> {
                g2d.setColor(this.color); 
                g2d.fillRoundRect(0, 0, W, H, 15, 15);

                JButton tempBtn = new JButton(contenuto);
                tempBtn.setSize(W, H);
                tempBtn.setFont(new Font("Arial", Font.BOLD, 40));
                tempBtn.setForeground(Color.BLACK); 

                tempBtn.setOpaque(false);
                tempBtn.setContentAreaFilled(false);
                tempBtn.setBorderPainted(false);

                tempBtn.printAll(g2d);
            }
        }

        g2d.dispose();
    }
}