package geometrydash;

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

/**
 * InputController gestisce tutti gli input dell'utente (Tastiera e Mouse).
 * Collega i tasti fisici alle azioni di gioco (salto, navigazione menu, strumenti editor).
 */
public class InputController {

    // Riferimenti ai componenti principali del gioco per invocare logica e cambiare stati
    private final GeometryDash  game;
    private final GamePanel      gamePanel;
    private final PlayerState   state;
    private final PhysicsEngine physics;
    private final EditorController editor;

    /**
     * Costruttore: riceve i riferimenti necessari per manipolare il gioco in risposta agli input.
     */
    public InputController(GeometryDash game, GamePanel gamePanel, PlayerState state,
                           PhysicsEngine physics, EditorController editor) {
        this.game      = game;
        this.gamePanel = gamePanel;
        this.state     = state;
        this.physics   = physics;
        this.editor    = editor;
    }

    /**
     * Configura il sistema di input inizializzando i timer e i binding.
     * @param cubo L'oggetto immagine del giocatore.
     * @param pavimento L'oggetto immagine del suolo.
     * @param contTimers Array di float per gestire accelerazioni/tempi specifici (es. navicella).
     */
    public void setup(Img cubo, Img pavimento, float[] contTimers) {
        // Crea il timer che gestisce la pressione continua del tasto salto
        Timer saltaTimer = buildSaltaTimer(cubo, pavimento, contTimers);
        
        // Collega i tasti della tastiera
        bindKeys(saltaTimer, cubo, contTimers);
        
        // Collega i clic del mouse
        bindMouse(saltaTimer, cubo, contTimers);
    }

    /**
     * Definisce il comportamento del giocatore mentre il tasto di interazione (SPAZIO o Click) è premuto.
     * Il Timer (8ms) simula il controllo continuo tipico di Geometry Dash.
     */
    private Timer buildSaltaTimer(Img cubo, Img pavimento, float[] contTimers) {
        return new Timer(8, e -> {
            switch (cubo.getTipo()) {
                case "cubo" -> {
                    // Se il cubo è a terra o tocca un orb, salta
                    if ((state.isGrounded || state.isTouchingOrb) && !state.isJumping) {
                        state.isJumping = true;
                        physics.saltaPlayer(cubo, "normale", pavimento);
                    }
                }
                case "navicella" -> {
                    if (state.isTouchingOrb) {
                        // Gli orb funzionano come salti singoli anche in navicella
                        state.isJumping = true;
                        physics.saltaPlayer(cubo, "normale", pavimento);
                    } else {
                        // Meccanica navicella: spinta verso l'alto progressiva
                        physics.muoviNavicella(cubo, contTimers[0]);
                        contTimers[0] += 0.7f; // Incrementa l'accelerazione di ascesa
                        if (contTimers[0] > 12) contTimers[0] = 12; // Limite velocità massima
                    }
                }
                case "palla" -> { 
                    // Meccanica palla: inverte la gravità solo se tocca una superficie
                    if (state.isGrounded) state.gravity *= -1; 
                }
            }
        });
    }

    /**
     * Configura i KeyBinding per la tastiera utilizzando InputMap e ActionMap (più stabili di KeyListener).
     */
    private void bindKeys(Timer saltaTimer, Img cubo, float[] contTimers) {
        InputMap im = gamePanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = gamePanel.getActionMap();

        // --- SPAZIO: Interazione primaria (Salto / Volo) ---
        bind(im, am, "SPACE", e -> { 
            if (gamePanel.isGameStarted) { 
                saltaTimer.start(); // Avvia il ciclo di salto/volo
            } 
        });

        bind(im, am, "released SPACE", e -> {
            saltaTimer.stop(); // Interrompe l'azione al rilascio
            if ("navicella".equals(cubo.getTipo())) {
                contTimers[0] = 0; // Resetta l'accelerazione navicella
                state.cont[0] = 0;
                physics.ripristinaFisica(); // Gestisce la caduta per gravità
            }
        });

        // --- ENTER: Avvia il test del livello dall'Editor ---
        bind(im, am, "ENTER", e -> {
            if (game.isEditing) {
                game.isEditing = false;
                game.cubo.setY(1030); // Posiziona il cubo sul suolo
                game.setGravity(1);
                game.setTipo("cubo");
                gamePanel.setIsGameStarted(true);
                gamePanel.schermataCorrente = "livelloInCorsoEditor";
                GeometryDash.livelli.get(0).ripristinaPosScena(); // Resetta offset camera
                game.gameLoop.start(); // Avvia il motore di gioco
            }
        });

        // --- ESCAPE: Torna indietro nei menu ---
        bind(im, am, "ESCAPE", e -> {
            try {
                gamePanel.tornaIndietro();
            } catch (IOException ex) {
            }
        });
        
        // --- BACKSPACE: Toggle visibilità sfondo (Debug/Estetica) ---
        bind(im, am, "BACK_SPACE", e -> {
            gamePanel.disattivaBackground = !gamePanel.disattivaBackground;
        });

        // --- FRECCE: Movimento Editor o Regolazione Volume ---
        String[] keys   = {"RIGHT", "LEFT", "UP", "DOWN"};
        String[] versi  = {"destra", "sinistra", "sopra", "sotto"};
        for (int i = 0; i < keys.length; i++) {
            final String verso = versi[i];
            bind(im, am, keys[i], e -> {
                if (game.isEditing) { 
                    editor.spostaScena(verso); // Muove la telecamera nell'editor
                    game.repaint(); game.revalidate(); 
                }
                else game.cambiaVolumeMusica(verso); // Regola audio in gioco
            });
        }

        // --- TASTI 1-9: Selezione rapida oggetti nell'Editor ---
        for (int i = 1; i <= 9; i++) {
            final int n = i;
            bind(im, am, String.valueOf(n), e -> {
                if (!game.isEditing) return;
                editor.setTipoSelezionato(switch (n) {
                    case 1 -> "spina";             case 2 -> "piattaforma";
                    case 3 -> "portaleGravitaGiallo"; case 4 -> "portaleGravitaBlu";
                    case 5 -> "portaleNavicella"; case 6 -> "portaleCubo";
                    case 7 -> "padGiallo";          case 8 -> "orbGiallo";
                    case 9 -> "fine";
                    default -> editor.getTipoSelezionato();
                });
            });
        }
    }

    /**
     * Gestisce le interazioni tramite Mouse (Click sinistro).
     */
    private void bindMouse(Timer saltaTimer, Img cubo, float[] contTimers) {
        game.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.getButton() != MouseEvent.BUTTON1) return; // Solo click sinistro

                if(gamePanel.menuEdit) { 
                    // Gestione selezione livelli nel menu editor
                    try {
                        gamePanel.controllaBottoniMenuEdit(e);
                    } catch (IOException ex) {
                    }
                }
                // Se siamo in gioco, il click avvia il salto
                else if (!game.isEditing && gamePanel.isGameStarted) {
                    saltaTimer.start();
                }
                // Se siamo nell'editor, il click posiziona un oggetto
                else if(game.isEditing) {
                    editor.prendiCoordinateMouse(e, gamePanel.scale);
                }
            }

            public void mouseReleased(MouseEvent e) {
                if (e.getButton() != MouseEvent.BUTTON1) return;
                saltaTimer.stop();
                if ("navicella".equals(cubo.getTipo())) {
                    contTimers[0] = 0;
                    state.cont[0] = 0;
                    physics.ripristinaFisica();
                }
            }
        });
    }

    /**
     * Metodo helper per abbreviare la sintassi di registrazione dei tasti.
     * Collega una stringa (tasto) a un'azione (consumer).
     */
    private void bind(InputMap im, ActionMap am, String key, java.util.function.Consumer<ActionEvent> action) {
        im.put(KeyStroke.getKeyStroke(key), key);
        am.put(key, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) { action.accept(e); }
        });
    }
}