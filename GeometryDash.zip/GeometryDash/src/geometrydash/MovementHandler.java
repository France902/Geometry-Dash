package geometrydash;

import javax.swing.Timer;
import java.io.IOException;
import java.util.ArrayList;

/**
 * MovementHandler coordina il movimento di tutti gli oggetti del livello rispetto al giocatore.
 * Gestisce la logica di scorrimento laterale, le interazioni con i portali di trasformazione
 * e la sequenza di morte/respawn.
 */
public class MovementHandler {

    private final PlayerState        state;
    private final GamePanel          gamePanel;
    private final PhysicsEngine      physics;
    private final CollisionHandler   collision;
    private final PlayerTransformer transformer;
    private final ArrayList<Livello> livelli;
    private final Runnable           onFineLivello;
    private final GeometryDash       mainframe;
    
    private Timer ripristinaTimer;
    private boolean mortePending = false;

    public MovementHandler(PlayerState state, GamePanel gamePanel, PhysicsEngine physics,
                           CollisionHandler collision, PlayerTransformer transformer,
                           ArrayList<Livello> livelli, Runnable onFineLivello, GeometryDash mainframe) {
        this.state         = state;
        this.gamePanel     = gamePanel;
        this.physics       = physics;
        this.collision     = collision;
        this.transformer   = transformer;
        this.livelli       = livelli;
        this.onFineLivello = onFineLivello;
        this.mainframe     = mainframe;
        
        this.ripristinaTimer = new Timer(600, e -> {
            mortePending = false;
            gamePanel.cuboDeleted = false;
            // Il cubo e pavimento vengono passati dopo — vedi sotto
        });
        this.ripristinaTimer.setRepeats(false);
    }

    /**
     * Metodo principale di aggiornamento. Viene chiamato ad ogni frame.
     * Implementa il "Parallasse" e sposta ogni elemento della scena.
     */
    public void updateMovement(
            ArrayList<Img> spini, ArrayList<Img> piattaforme,
            ArrayList<Img> portaliGravitaGiallo, ArrayList<Img> portaliGravitaBlu,
            ArrayList<Img> portaliNavicella, ArrayList<Img> portaliCubo,
            ArrayList<Img> fine, ArrayList<Img> padGialli, ArrayList<Img> orbGialli,
            ArrayList<Img> backgroundTexture, ArrayList<Img> groundTexture,
            Img cubo, Img pavimento, double deltaTime, LevelManager levelManager) {
        
        

        if (gamePanel.cuboDeleted) return; // Se il giocatore è morto, ferma il movimento
        if (mortePending) return;

        // Timer per gestire il respawn dopo la morte
        Timer ripristinaTimer = buildRipristinaTimer(cubo, levelManager, pavimento);
        
        // Calcolo dello spostamento basato sul tempo trascorso (frame independent movement)
        // 800 pixel al secondo è la velocità standard
        double spostamento = 1000.0 * deltaTime;  // float puro, niente arrotondamento
        
        // --- GESTIONE OSTACOLI (SPINE) ---
        for (Img spina : spini) {
            if (!collision.controllaTocco(spina, cubo)) {
                spina.setX((float) (spina.getX() - spostamento));
            } else {
                morte(ripristinaTimer); // Collisione rilevata -> morte
            }
        }

        // --- GESTIONE PIATTAFORME ---
        for (Img p : piattaforme) {
            if (!collision.controllaTocco(p, cubo)) {
                p.setX((float) (p.getX() - spostamento));
            } else {
                // Se tocca la piattaforma lateralmente invece che da sopra/sotto, il giocatore muore
                boolean collisioneLaterale = (state.gravity == 1)
                    ? Math.abs(p.getY() - cubo.getY()) <= 60
                    : Math.abs(p.getY() - cubo.getY()) > 120;

                if (collisioneLaterale && state.gravityIsChanged) morte(ripristinaTimer);
                else p.setX((float) (p.getX() - spostamento));
            }
        }

        // --- PORTALI DI TRASFORMAZIONE (Navicella / Cubo) ---
        for (Img portale : portaliNavicella) {
            portale.setX((float) (portale.getX() - spostamento));
            if (collision.controllaTocco(portale, cubo) && portale.getIsValid()) {
                portale.setIsValid(false); // Impedisce attivazioni multiple
                cubo.setRotation(0);
                transformer.trasformaNavicella(cubo);
            }
        }

        for (Img portale : portaliCubo) {
            portale.setX((float) (portale.getX() - spostamento));
            if (collision.controllaTocco(portale, cubo) && portale.getIsValid()) {
                portale.setIsValid(false);
                physics.ripristinaFisica();
                cubo.setRotation(0);
                transformer.trasformaCubo(cubo);
            }
        }

        // --- PORTALI DI GRAVITÀ ---
        for (Img portale : portaliGravitaGiallo) {
            portale.setX((float) (portale.getX() - spostamento));
            if (collision.controllaTocco(portale, cubo) && portale.getIsValid()) {
                portale.setIsValid(false);
                state.gravityIsChanged = false;
                physics.cambiaGravita("giallo");
                scheduleGravityReset(); // Breve cooldown per evitare bug di collisione
            }
        }

        for (Img portale : portaliGravitaBlu) {
            portale.setX((float) (portale.getX() - spostamento));
            if (collision.controllaTocco(portale, cubo) && portale.getIsValid()) {
                portale.setIsValid(false);
                state.gravityIsChanged = false;
                physics.cambiaGravita("blu");
                scheduleGravityReset();
            }
        }

        // --- PAD E ORB (Salto potenziato) ---
        for (Img pad : padGialli) {
            pad.setX((float) (pad.getX() - spostamento));
            if (collision.controllaTocco(pad, cubo) && pad.getIsValid()) {
                pad.setIsValid(false);
                state.isJumping = true;
                physics.saltaPlayer(cubo, "potenziato", pavimento);
            }
        }

        state.isTouchingOrb = false;
        for (Img orb : orbGialli) {
            orb.setX((float) (orb.getX() - spostamento));
            if (collision.controllaTocco(orb, cubo)) state.isTouchingOrb = true;
        }

        // --- EFFETTO PARALLASSE (Sfondo più lento del terreno) ---
        int sfondoSpost = (int) Math.round(90 * deltaTime);
        for (Img bg : backgroundTexture) bg.setX(bg.getX() - sfondoSpost);
        for (Img gnd : groundTexture)   gnd.setX((float) (gnd.getX() - spostamento));
        
        // --- FINE LIVELLO ---
        for (Img f : fine) {
            f.setX((float) (f.getX() - spostamento));
            if (collision.controllaTocco(f, cubo)) {
                onFineLivello.run(); // Attiva la logica di vittoria
            }
        }
    }

    /**
     * Gestisce l'esplosione del giocatore e avvia il timer di respawn.
     */
    private void morte(Timer timer) {
        gamePanel.deleteCubo(); // Rimuove visivamente il giocatore
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Costruisce la logica di ripristino del livello.
     * Resetta le variabili di stato e riporta il giocatore all'inizio.
     */
    private Timer buildRipristinaTimer(Img cubo, LevelManager levelManager, Img pavimento) {
        return new Timer(600, e -> {
            gamePanel.cuboDeleted = false;
            cubo.setRotation(0);
            cubo.setY(1050);
            pavimento.setY(1150);
            transformer.trasformaCubo(cubo);
            state.gravity    = 1; // Resetta gravità normale
            state.isGrounded = true;
            try { 
                levelManager.ricominciaLivello(); 
            } catch (IOException ex) { 
                ex.printStackTrace(); 
            }
            mainframe.isEditing = false;
        });
    }

    /**
     * Timer di sicurezza per evitare che la collisione con un portale
     * venga registrata più volte o causi morti istantanee.
     */
    private void scheduleGravityReset() {
        Timer t = new Timer(500, e -> {
            state.gravityIsChanged = true;
            ((Timer) e.getSource()).stop();
        });
        t.setRepeats(false);
        t.start();
    }
}