package geometrydash;

import java.awt.Rectangle;
import java.util.ArrayList;

/**
 * CollisionHandler gestisce la logica delle collisioni tra il giocatore e gli elementi del mondo.
 * Utilizza la classe Rectangle di AWT per calcolare le intersezioni geometriche.
 */
public class CollisionHandler {

    private final PlayerState state;
    // Rettangoli riutilizzati per evitare continue allocazioni di memoria (ottimizzazione)
    private final Rectangle r1 = new Rectangle();
    private final Rectangle r2 = new Rectangle();

    public CollisionHandler(PlayerState state) {
        this.state = state;
    }

    /**
     * Controlla se il giocatore sta toccando una superficie solida (pavimento o piattaforme).
     * Gestisce il posizionamento del giocatore per evitare che "affondi" negli oggetti.
     * * @param obj1 Il giocatore.
     * @param floor Il suolo principale.
     * @param platforms Lista delle piattaforme presenti nel livello.
     * @param rect1 Rettangolo di collisione del giocatore.
     * @param rect2 Rettangolo di collisione dell'oggetto target.
     * @return true se è avvenuta una collisione che ha richiesto un riposizionamento.
     */
    public boolean checkCollisionGravity(Img obj1, Img floor, ArrayList<Img> platforms, Rectangle rect1, Rectangle rect2) {

        // --- CASO 1: Gravità Normale (Verso il basso) ---
        if (state.gravity == 1) {
            // Collisione con il pavimento principale
            if (rect1.intersects(rect2)) {
                obj1.setY(floor.getY() - 97); // Snap sopra il pavimento (97 è l'altezza compensata del cubo)
                state.isGrounded = true;
                return true;
            }
            // Collisione con le piattaforme
            for (Img p : platforms) {
                rect2.setBounds((int)p.getX(), (int)p.getY(), p.getW(), p.getH());
                // Verifica se il giocatore atterra sulla piattaforma (dall'alto)
                if (rect1.intersects(rect2) && obj1.getY() <= p.getY()) {
                    obj1.setY(p.getY() - 97);
                    state.isGrounded = true;
                    return true;
                }
            }
            
            /* * "Buffer" di prossimità: espande il rettangolo per rilevare se il giocatore
             * è quasi a terra, utile per permettere il salto un istante prima del tocco effettivo.
             */
            rect1.grow(30, 30);
            rect2.setBounds((int)floor.getX(), (int)floor.getY(), floor.getW(), floor.getH());
            if (rect1.intersects(rect2)) { state.isGrounded = true; return false; }
            
            for (Img p : platforms) {
                rect2.setBounds((int)p.getX(), (int)p.getY(), p.getW(), p.getH());
                if (rect1.intersects(rect2) && obj1.getY() <= p.getY()) {
                    state.isGrounded = true;
                    return false;
                }
            }
            
        // --- CASO 2: Gravità Invertita (Verso l'alto) ---
        } else {
            // Collisione con il soffitto (pavimento invertito)
            if (rect1.intersects(rect2) && obj1.getY() > floor.getY()) {
                obj1.setY(floor.getY() + floor.getH() + 2); // Snap sotto il soffitto
                state.isGrounded = true;
                return true;
            }
            for (Img p : platforms) {
                rect2.setBounds((int)p.getX(), (int)p.getY(), p.getW(), p.getH());
                if (rect1.intersects(rect2) && obj1.getY() > p.getY()) {
                    state.isGrounded = true;
                    return true;
                }
            }
            
            // Espansione del raggio di rilevamento per gravità invertita
            rect1.grow(20, 20);
            rect2.setBounds((int)floor.getX(), (int)floor.getY(), floor.getW(), floor.getH());
            if (rect1.intersects(rect2) && obj1.getY() > floor.getY()) { state.isGrounded = true; return false; }
            
            for (Img p : platforms) {
                rect2.setBounds((int)p.getX(), (int)p.getY(), p.getW(), p.getH());
                if (rect1.intersects(rect2) && obj1.getY() > p.getY()) {
                    obj1.setY(p.getY() + p.getH() + 40);
                    state.isGrounded = true;
                    return false;
                }
            }
        }
        
        // Se nessun controllo ha avuto successo, il giocatore è in aria
        state.isGrounded = false;
        return false;
    }

    /**
     * Verifica una collisione generica tra due oggetti.
     * Include una logica di "Hitbox Padding" per rendere il gioco più equo.
     * * @param obj1 Solitamente l'ostacolo (es. spina).
     * @param obj2 Solitamente il giocatore.
     * @return true se gli oggetti si stanno toccando.
     */
    public boolean controllaTocco(Img obj1, Img obj2) {
        /*
         * Se l'oggetto è una "spina", riduce la hitbox di 80 pixel complessivi.
         * Questo permette al giocatore di "sfiorare" i bordi dei triangoli senza morire,
         * migliorando il gamefeel (meccanica tipica di Geometry Dash).
         */
        int offset = "spina".equals(obj1.getTipo()) ? 80 : 0;
        
        r1.setBounds(
            (int)Math.round(obj1.getX() + offset / 2.0), 
            (int)Math.round(obj1.getY() + offset),       
            obj1.getW() - offset,                       
            obj1.getH() - offset                         
        );
        
        r2.setBounds((int)obj2.getX(), (int)obj2.getY(), obj2.getW(), obj2.getH());
        
        return r1.intersects(r2);
    }
}