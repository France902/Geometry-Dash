
package geometrydash;

import java.util.ArrayList;

public class Livello {
    private int lMSpino = 50, AMSpino = 50;
    private ArrayList<Img> spiniLivello = new ArrayList<>();
    private ArrayList<Img> piattaformeLivello = new ArrayList<>();
    public Livello(int numero) {
        switch(numero) {
            case 1:
                creaLivelloUno();
                break;
        }
    }
    
    public void creaLivelloUno() {
        // VARIABILI DI COMODITÀ
    int groundY = 900; // La base dove poggiano gli spini
    int step = 360;    // Distanza percorsa in 1 secondo (6 unità * 60 fps)

    // --- SECONDO 1-3: INTRODUZIONE (Spini singoli e doppi) ---
    // Spino singolo a 2 secondi
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, step * 2, groundY));
    
    // Spino doppio a 3.5 secondi
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, (int)(step * 3.5), groundY));
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, (int)(step * 3.5) + 50, groundY));

    // --- SECONDO 4-7: PIATTAFORME (Salti a mezz'aria) ---
    // Prima piattaforma sollevata
    piattaformeLivello.add(new Img("/resources/images/anonimo.png", "pavimento", 150, 40, step * 5, groundY - 120));
    // Spino sopra la piattaforma per cattiveria
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, step * 5 + 50, groundY));

    // Successione di tre piattaforme (scale)
    piattaformeLivello.add(new Img("/resources/images/anonimo.png", "pavimento", 150, 40, step * 7, groundY - 100));
    piattaformeLivello.add(new Img("/resources/images/anonimo.png", "pavimento", 150, 40, step * 7 + 300, groundY - 200));
    piattaformeLivello.add(new Img("/resources/images/anonimo.png", "pavimento", 150, 40, step * 7 + 500, groundY - 300));

    // --- SECONDO 8-10: TRIPLICE SPINO (Il classico di GD) ---
    int tripleX = step * 10;
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, tripleX, groundY));
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, tripleX + 45, groundY));
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, tripleX + 90, groundY));
    
    spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, step * 12, groundY));

    // --- SECONDO 11-15: SEZIONE NAVICELLA (Tunnel) ---
    // Portale trasformazione (immaginario, lo mettiamo a 10.5s)
    // Qui dovresti chiamare trasformaNavicella quando il player tocca questa X
    
    // Tunnel stretto fatto di piattaforme sopra e sotto
    for(int i = 0; i < 10; i++) {
        int xNav = step * 13 + (i * 200);
        // Soffitto
        piattaformeLivello.add(new Img("/resources/images/anonimo.png", "pavimento", 200, 40, xNav, groundY - 500));
        // Pavimento (più alto del solito per stringere il tunnel)
        piattaformeLivello.add(new Img("/resources/images/anonimo.png", "pavimento", 200, 40, xNav, groundY - 100));
        
        // Ostacoli in mezzo al tunnel ogni 2 blocchi
        if(i % 2 == 0) {
            spiniLivello.add(new Img("/resources/images/anonimo.png", "spina", lMSpino, AMSpino, xNav + 200, groundY - 140)); // Spino a testa in su
        }
    }
    }
    
    public ArrayList<Img> getSpini() {
        return spiniLivello;
    }
    
    public ArrayList<Img> getPiattaforme() {
        return piattaformeLivello;
    }
}
