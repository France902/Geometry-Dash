package geometrydash;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage; 
import java.util.ArrayList;
import javax.swing.JPanel;

class GamePanel extends JPanel {
    Img cubo;
    Img piattaforma;
    ArrayList<Img> spini;
    ArrayList<Img> piattaforme;

    public GamePanel(Img cubo, Img piattaforma, ArrayList<Img> spini, ArrayList<Img> piattaforme) {
        this.cubo = cubo;
        this.piattaforma = piattaforma;
        this.spini = spini;
        this.piattaforme = piattaforme;
        setOpaque(true);
        setBackground(Color.WHITE); 
    }

    @Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g); 
        Graphics2D g2d = (Graphics2D) g;

        
        g2d.drawImage(piattaforma.getBufferedImage(), 
            piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH(), null);
        
        // Disegno Spina
        for(Img spina : spini) {
            g2d.drawImage(spina.getBufferedImage(), 
            spina.getX(), spina.getY(), spina.getW(), spina.getH(), null);
        }
        
        for(Img piattaforma : piattaforme) {
            g2d.drawImage(piattaforma.getBufferedImage(), 
            piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH(), null);
        }
                                    
        if(!cubo.getIsDeleted()) {
            // Salviamo la trasformazione corrente
            AffineTransform old = g2d.getTransform();
            
            // Spostiamo l'origine al centro del cubo per ruotarlo correttamente
            g2d.translate(cubo.getX() + cubo.getW() / 2, cubo.getY() + cubo.getH() / 2);
            g2d.rotate(Math.toRadians(cubo.getRotation()));

            // Disegniamo la BufferedImage centrata rispetto al punto di traslazione
            BufferedImage imgCubo = cubo.getBufferedImage();
            g2d.drawImage(imgCubo, -cubo.getW() / 2, -cubo.getH() / 2, cubo.getW(), cubo.getH(), null);

            // Ripristiniamo la trasformazione originale
            g2d.setTransform(old);
        }
        
        
    }
    
    public Img getCubo() { return cubo; }
    
    public void deleteCubo() {
        cubo.delete();
    }
}