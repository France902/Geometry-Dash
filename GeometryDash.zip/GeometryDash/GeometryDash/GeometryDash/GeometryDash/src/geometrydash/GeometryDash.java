
    package geometrydash;

    import java.awt.Color;
    import java.awt.Graphics;
    import java.awt.Graphics2D;
    import java.awt.Image;
    import java.awt.Rectangle;
    import java.awt.event.*;
    import java.awt.geom.AffineTransform;
    import java.awt.image.BufferedImage;
    import java.util.LinkedList;
    import java.util.Random;
    import javax.swing.*;
    import java.net.URL;
import java.util.ArrayList;
    import java.util.Arrays;
    

    public class GeometryDash extends JFrame {

        JFrame frame = new JFrame();        
        
        static int W = 100, H = 100, WS = 1000, HS = 1000, playerX = 50, playerY = 860;
        GamePanel gamePanel;
        boolean isJumping = false;
        boolean isGrounded = false;
        boolean suspendPhysics = false;
        
        static ArrayList<Livello> livelli = new ArrayList<>();

        public GeometryDash() {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            frame.setTitle("Scatto Geometrico");

            frame.setLayout(new java.awt.BorderLayout());

            Img cubo = new Img("/resources/images/Cubo.png", "cubo", W, H, playerX, playerY);
            Img pavimento = new Img("/resources/images/anonimo.png", "pavimento", 1000000, 120, -20, 950);

            gamePanel = new GamePanel(cubo, pavimento, livelli.get(0).getSpini(), livelli.get(0).getPiattaforme());
            frame.add(gamePanel, java.awt.BorderLayout.CENTER); 

            frame.setFocusable(true);
            frame.requestFocusInWindow();
            
            int[] cont = {0};

            frame.addKeyListener(new KeyAdapter() {
                boolean isSpacePressed = false;    
                float[] contTimers = {0};
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                        System.exit(0);
                    } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                        isSpacePressed = true;
                        switch(cubo.getTipo()) {
                            case "cubo":
                                if(isGrounded && !isJumping) {
                                    isJumping = true;
                                    saltaPlayer(cubo);
                                }
                                break;
                            case "navicella":
                                muoviNavicella(cubo, contTimers[0]);
                                contTimers[0] += 0.7f;
                                if(contTimers[0] > 12) contTimers[0] = 12;
                                break;
                        }
                            
                    } else if (e.getKeyCode() == KeyEvent.VK_1) {
                            if(isGrounded && !isJumping) {
                                trasformaNavicella(cubo);
                                cubo.setRotation(0);
                            }
                    }
                }
                
                @Override
                public void keyReleased(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                        isSpacePressed = false; 
                        contTimers[0] = 0;
                        cont[0] = 0;

                        if (cubo.getTipo().equals("navicella")) {
                            ripristinaFisica(); 
                        }
                    }
                }
            });

            frame.setVisible(true);
            
            
            
            Timer gameLoop = new Timer(16, e -> {
                if(!suspendPhysics) {
                    if(!checkCollisionGravity(cubo, pavimento, livelli.get(0).getPiattaforme()) && !isJumping) {
                        updatePhysics(cubo, pavimento, cont[0]);
                        cont[0]++;
                    }
                    else {
                        if(cubo.getRotation() != 90) {
                        cont[0] = 0;
                        }
                        if(!isJumping) {
                            raddrizzaCubo(cubo);
                        }
                    }
                    
                }
                updateMovement(livelli.get(0).getSpini(), livelli.get(0).getPiattaforme(), cubo);                 
                gamePanel.repaint(); 
                
            });
            gameLoop.start();
        }
        
        public void trasformaNavicella(Img cubo) {
            cubo.setTipo("navicella");
            try {
                URL resource = getClass().getResource("/resources/images/anonimo.png");
                BufferedImage nuovaImg = javax.imageio.ImageIO.read(resource);

                cubo.setBufferedImage(nuovaImg); 

                gamePanel.repaint();

            } catch (Exception e) {
                System.out.println("Errore nel caricamento dell'immagine navicella: " + e.getMessage());
            }
        }
        
        public void muoviNavicella(Img navicella, float cont) {
            sospendiFisica();
            int currentY = navicella.getY();
            float rotation = navicella.getRotation();
            rotation -= 1.5f;
            if(rotation <= -30) rotation = -30;     
            navicella.setRotation(rotation);
            currentY -= (3 + cont);
            navicella.setY(currentY);
        }
        
        public void sospendiFisica() {
            suspendPhysics = true;
        }
        
        public void ripristinaFisica() {
            suspendPhysics = false;
        }
        
        public void updatePhysics(Img cubo, Img pavimento, int cont) {
                    int currentY = cubo.getY();
                    int currentX = cubo.getX();
                    float rotation = cubo.getRotation();
                    float speed;
                    if(cubo.getTipo().equals("cubo")) {
                        rotation += 2.30f;
                        if(rotation >= 360) rotation -= 360;
                        cubo.setRotation(rotation);
                        speed = 0.7f*cont;
                    } else {
                        rotation += 1.50f;
                        if(rotation >= 30) rotation = 30;
                        cubo.setRotation(rotation);
                        speed = 0.4f*cont;
                    }  
                    
                    
                    
                    if(speed > 30) speed = 30;

                    currentY += speed;

                    cubo.setY(currentY);
 
            
        }
        
        public void raddrizzaCubo(Img cubo) {
            int i, index = 0, verso;
            int[] closerAngle = {90};
            float[] rotation = {cubo.getRotation()};
            float[] differences = {Math.abs(0 - rotation[0]), Math.abs(90 - rotation[0]), Math.abs(180 - rotation[0]), Math.abs(270 - rotation[0]), Math.abs(360 - rotation[0])};
            float min = differences[0];

            for(i=1;i<4;i++) {
                if(min > differences[i]) {
                    index = i;
                    min = differences[i];
                }
            }

            switch(index) {
                case 0:
                    closerAngle[0] = 0;
                    break;
                case 1:
                    closerAngle[0] = 90;
                    break;
                case 2:
                    closerAngle[0] = 180;
                    break;
                case 3:
                    closerAngle[0] = 270;
                    break;
                case 4:
                    closerAngle[0] = 360;
                    break;
                default:
                    closerAngle[0] = 0;
                    break;
            }

            if(closerAngle[0] - rotation[0] >= 0) verso = 1;
            else verso = -1;
            if(Math.abs(closerAngle[0] - rotation[0]) > 6) rotation[0] += (6*verso);
            else rotation[0] = closerAngle[0];

            cubo.setRotation(rotation[0]);
        }
        
        public boolean checkCollisionGravity(Img oggetto1, Img oggetto2, ArrayList<Img> piattaforme) {
            Rectangle rect1 = new Rectangle(oggetto1.getX(), oggetto1.getY(), oggetto1.getW(), oggetto1.getH());
            Rectangle rect2 = new Rectangle(oggetto2.getX(), oggetto2.getY(), oggetto2.getW(), oggetto2.getH());

            if (rect1.intersects(rect2)) {
                isGrounded = true;
                return true;
            } 
            
            for(Img piattaforma : piattaforme) {
                rect2 = new Rectangle(piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH());
                
                if (rect1.intersects(rect2)) {
                   isGrounded = true;
                    return true;
                } 
            }
            
            rect1.grow(20, 20);
            
            if (rect1.intersects(rect2)) {
                isGrounded = true;
                return false;
            } 
            
            for(Img piattaforma : piattaforme) {
                rect2 = new Rectangle(piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH());
                
                if (rect1.intersects(rect2)) {
                    isGrounded = true;
                    return false;
                } 
            }
            isGrounded = false;
            return false;
        }
        
        public boolean controllaToccoSpino(Img oggetto1, Img oggetto2) {
            Rectangle rect1 = new Rectangle(oggetto1.getX(), oggetto1.getY(), oggetto1.getW(), oggetto1.getH());
            Rectangle rect2 = new Rectangle(oggetto2.getX(), oggetto2.getY(), oggetto2.getW(), oggetto2.getH());

            if (rect1.intersects(rect2)) {
                return true;
            } 
            return false;
        }
        
        public void saltaPlayer(Img cubo) {
            float[] cont = {0};
            
            Timer jumpTimer = new Timer(16, e -> {
                if(isJumping) {
                    int currentY = cubo.getY();
                    int currentX = cubo.getX();
                    float rotation = cubo.getRotation();
                    
                    rotation += 1.5;
                    cubo.setRotation(rotation);
                    currentY -= 22 - cont[0];

                    cubo.setY(currentY);

                    cont[0] += 1f;
                    
                    if(cont[0] >= 23) {
                        isJumping = false;
                        ((Timer)e.getSource()).stop();
                    }
                }
                
            });
            
            jumpTimer.start();
        }
        
        public void updateMovement(ArrayList<Img> spini, ArrayList<Img> piattaforme, Img cubo) {
                if(cubo.getIsDeleted()) return;
                for(Img spina : spini) {
                    if(!controllaToccoSpino(spina, cubo)) {
                        int currentY = spina.getY();
                        int currentX = spina.getX();

                        currentX -= 6;
                        spina.setX(currentX);
                    } else {
                        cubo.delete();
                        gamePanel.deleteCubo();
                    }
                }
                
                for(Img piattaforma : piattaforme) {
                    if(!controllaToccoSpino(piattaforma, cubo)) {
                        int currentY = piattaforma.getY();
                        int currentX = piattaforma.getX();

                        currentX -= 6;
                        piattaforma.setX(currentX);
                    } else {
                        if(Math.abs(piattaforma.getY() - cubo.getY()) <= 70) {
                            cubo.delete();
                            gamePanel.deleteCubo();
                        } else {
                            
                            int currentY = piattaforma.getY();
                            int currentX = piattaforma.getX();
        
                            currentX -= 6;
                            piattaforma.setX(currentX);
                        }
                        
                    }
                }
                
                
        }
        

        public static void main(String[] args) {
            creaLivelli();
            new GeometryDash();
        }
        
        public static void creaLivelli() {
            livelli.add(new Livello(1));
        }

    }
